% Model_2a
%
% Purpose: This algorithm models the expected utility of an risk averse
% individual; when presented with two risky assets. The model could be 
% modified through the Random_VarGen2 function to base the asset variable 
% with vary of different distributions. The model focus is to determine the
% optimal investment in-between the two risky assets by the risk-averse
% individual, for a vary of different distributions. 
% 
% 
% Barry Daemi
% Departmental Distinction Paper - 
%    Portfolio Diverification - An Introduction to Numerical Methods
% March 31, 2019
% Southern Methodist University

clear
close all

% Initial Wealth
w0=5000;
% Rate-of-return of Risky asset, and probability
n=1000; [x]=Random_VarGen2(n,'Beta'); 
figure
h1=histogram(x(1,:)); counts1=h1.Values; total1=sum(counts1);
probs1=counts1/total1;
figure
h2=histogram(x(2,:)); counts2=h2.Values; total2=sum(counts2);
probs2=counts2/total2;
probs=probs1'*probs2; probs=probs(:);
% Investment into the risky asset
alpha=0:50:5000; alpha=alpha';
% Wealth States Matrix with an static Alpha investmennt
for i=1:length(x(1,:))
    for j=1:length(x(2,:))
        W(i,j)=(alpha(1,1)*x(1,i))+((w0-alpha(1,1))*x(2,i));
    end
end
% Expected Utility Matrix wirh an static Alpha investment
for k=1:length(probs)
    for l=1:length(counts1)
        EU(l,k)=probs(k)*log(W(k,l));
    end
end

% Expected Utility with an static alpha investment
EU=sum(sum(EU));
% Wealth States Array with variations in the Alpha investment
for m=1:length(alpha)
    for n=1:length(x(1,:))
        for o=1:length(x(2,:))
            beta(m,1)=w0-alpha(m,1);
            WM(n,o,m)=(alpha(m,1)*x(1,n))+(w0-alpha(m,1))*(x(2,o));
        end
    end
end
% Expected Utility Array with variations in the Alpha investment
%WM=sum(WM); WM=reshape(WM,[n,length(alpha)]);
for p=1:length(probs)
    for q=1:length(counts1)
        for r=1:length(counts2)
            for s=1:length(alpha)
                EUA(q,r,p,s)=probs(p)*log(WM(q,r,s));
            end
        end
    end
end
% Expected utility with variations in the Alpha investment
EUA=sum(sum(sum(EUA)));
EUAS=reshape(EUA,[length(alpha),1]);
EUAS=real(EUAS);
% The optimal investment in-between the two risky asset

% Plots 
hold on
figure
plot(alpha,EUAS)
plot(beta,EUAS)
title('Expected Utility Curve - Expected Utility against Alpha Investment')
xlabel('Alpha investment into the Risky Asset')
ylabel('Expected Utility')
hold off

            













        
    
