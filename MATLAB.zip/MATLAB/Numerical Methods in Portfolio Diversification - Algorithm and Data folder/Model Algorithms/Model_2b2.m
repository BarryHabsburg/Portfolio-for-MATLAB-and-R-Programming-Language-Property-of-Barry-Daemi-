% Model_2b
%
% Purpose: This code is to simulate a portfiolo containing
% two risky assets, such as, publically trade commmerical stock.
%
% Note: This algorithm is broken. What also quite interesting is that it is
% broken in the same way as the previous continuous model - involving
% numerical integration. *sighs heavily*
% 
% Barry Daemi
% Departmental Distinction Research Paper
% March 31, 2019
% Southern Methodist University

clear
close all

% Initial Wealth
w0=5000;
% Investment into the risky asset
alpha=250:50:5000; alpha=alpha';
% 
N=[20 50 100 200 400 800 1600];  
% Number of iterations, and variations in risk aversion
u=7; 
% Storage vector for Expected Utility from each respective iteration of the
% loop
EUS=zeros(u,length(alpha));
for t=1:u

    % Rate-of-return of Risky asset, and probability
    x=Random_VarGen2(N(t),'Inverse Transform Method'); % x=sort(x(1,:));
    figure
    h1=histogram(x(1,:)); counts1=h1.Values; total1=sum(counts1);
    probs1=counts1/total1;
    figure
    h2=histogram(x(2,:)); counts2=h2.Values; total2=sum(counts2);
    probs2=counts2/total2;
    probs=probs1'*probs2; probs=probs(:);
    % Wealth States Matrix with an static Alpha investmennt
    for i=1:length(x(1,:))
        for j=1:length(x(2,:))
            W(i,j)=(alpha(1,1)*x(1,i))+((w0-alpha(1,1))*x(2,i));
        end
    end
    % Expected Utility Matrix wirh an static Alpha investment
    for k=1:length(probs)
        for l=1:length(counts1)
            EU(l,k)=probs(k)*log(W(k,l));
        end
    end
    % Expected Utility with an static alpha investment
    EU=sum(sum(EU));
    % Wealth States Array with variations in the Alpha investment
    for m=1:length(alpha)
        for n=1:length(x(1,:))
            for o=1:length(x(2,:))
                beta(m,1)=w0-alpha(m,1);
                WM(n,o,m)=(alpha(m,1)*x(1,n))+(w0-alpha(m,1))*(x(2,o));
            end
        end
    end
    % Expected Utility Array with variations in the Alpha investment
    %WM=sum(WM); WM=reshape(WM,[n,length(alpha)]);
    for p=1:length(probs)
        for q=1:length(counts1)
            for r=1:length(counts2)
                for s=1:length(alpha)
                    EUA(q,r,p,s)=probs(p)*log(WM(q,r,s));
                end
            end
        end
    end
    % Expected utility with variations in the Alpha investment
    EUA=sum(sum(sum(EUA)));
    EUAS=reshape(EUA,[length(alpha),1]);
    EUAS=real(EUAS);
    % The optimal investment in-between the two risky asset

    % Storing the current iterations Expected Utility curve
    EUS(t,:)=EUAS;
end

% Plots - add labeling to the graph
figure
hold on
plot(alpha,EUS(1,:))
plot(alpha,EUS(2,:))
plot(alpha,EUS(3,:))
plot(alpha,EUS(4,:))
plot(alpha,EUS(5,:))
plot(alpha,EUS(6,:))
plot(alpha,EUS(7,:))
plot(alpha,EUS(8,:))
plot(alpha,EUS(9,:))
plot(alpha,EUS(10,:))
title('Expected Utility Curve - Expected Utility against Alpha Investment')
xlabel('Alpha investment into the Risky Asset')
ylabel('Expected Utility')
hold off

