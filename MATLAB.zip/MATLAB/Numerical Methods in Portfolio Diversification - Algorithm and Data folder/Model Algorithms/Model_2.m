% Model_2
%
% Purpose: This code is to simulate a portfiolo containing
% two asssets risky asset, such as, a common and
% publically trade commmerical stock.
% 
% Note: You should be able to tell this was actually created on
%       March 13, 2019, and not recently, as the misleading dates
%       would suggest. The notation I utilized in this older model
%       is now a bit outdated. I did change variable a, back into
%       alpha to make continuity with the rest of the recently 
%       created models.
%
% Barry Daemi
% Departmental Distinction Research Paper
% March 31, 2019
% Southern Methodist University

clear
clear all
close all

% initial wealth
w0=5000;
% Random Variable X and Y: Probability Vectors and Matrix
X=[1/2 1/2]; Y=[1/4 3/4]; P=X'*Y; [m1,n1]=size(P); 
probs=reshape(P,[m1+n1,1]);
rate=[0.01 0.03 0.02 0.03]; rate=rate';
% Investment into the risky asset
alpha=0:10:5000; alpha=alpha';
% Wealth States vector with an static Alpha investmennt
parfor i=1:(m1+n1)
    W(i,1)=(alpha(1,1)*(1+rate(i,1)))+((w0-alpha(1,1))*(1+rate(i,1)));
end
% Expected Utility vector wirh an static Alpha investment
parfor k=1:length(probs)
    EU(k,1)=probs(k,1)*log(W(k,1));
end
% Expected Utility with an static Alpha investment
EU=sum(EU);
% Wealth States Array with variations in the Alpha investment
for m=1:length(alpha)
    for n=1:(m1+n1)
        beta(m,1)=w0-alpha(m,1);
        WM(n,m)=(alpha(m,1)*(1+rate(n,1)))+((w0-alpha(m,1))*(1+rate(n,1)));
    end
end
% Expected Utility Array with variations in the Alpha investment
for o=1:length(alpha)
    for p=1:(m1+n1)
        EUM(p,o)=probs(p,1)*log(WM(p,o));
    end
end
% Expected utility with variations in the Alpha investment
EUM=sum(EUM);
EUMS=reshape(EUM,[length(alpha),1]);
EUMS=real(EUMS);
% The optimal investment in-between the two risky asset
%lamda=((rate(1)-rate(2))*(rate(3)-rate(4))*(probs(1)+probs(4))+rate(4)*w0*probs(1)*(rate(1)-rate(2))+rate(2)*w0*probs(4)*(rate(3)-rate(4)))/(2*(rate(1)-rate(4))*(rate(3)-rate(2))+rate(2)*w0*(rate(1)-rate(4))+rate(4)*w0*(rate(3)-rate(2)))*probs(2);
%star_alpha= - (rate(4)*w0((rate(1)-rate(2))-(rate(3)-rate(2)))+rate(2)*w0*((rate(3)-rate(4))-(rate(1)-rate(4))))+sqrt(((rate(4)*w0*((rate(1)-rate(2))-(rate(3)-rate(2)))+rate(2)*w0*((rate(3)-rate(4))-(rate(1)-rate(4)))))^(2)-4*((rate(1)-rate(2))*(rate(3)-rate(4))-(rate(1)-rate(4))*(rate(3)-rate(2)))*lamda)/(2*(((rate(1)-rate(2))*(rate(3)-rate(4))-(rate(1)-rate(4))*(rate(3)-rate(2)))));


% Plots 
hold on
plot(alpha,EUMS)
plot(beta,EUMS)
title('Expected Utility Curve - Expected Utility against Alpha Investment')
xlabel('Alpha investment into the Risky Asset')
ylabel('Expected Utility')
hold off