% Model_1b
%
% Purpose: This code is to simulate a portfiolo containing one riskless
% assset, one risky asset. 
% This algorithm models the expected utility of an risk averse
% individual; when presented with one risky asset, and one riskles asset. 
% The model could be modified through the Random_VarGen function to base 
% the risky asset variable with vary of different distributions. 
% The model focus is to determine the optimal investment in-between the 
% risky asset, and riskless asset by the risk averse individual.
%
% Note: Subpart b) The additional focus of this model was aimed towards
%       consructing a plot with a utility function that variated in 
%       risk aversion. The plot was constructed with the 
%       expect utility curve to mapped to each respective risk averse 
%       utility function - which gradually had risk aversion incease as
%       the respective variable beta increased over each iteration. 
%       
%
% Barry Daemi
% Departmental Distinction Paper
% March 31, 2019
% Southern Methodist University

clear
close all

% Initial Wealth
w0=5000;
% Rate-of-Return of Riskless Asset
r=0.050;
% Rate-of-return of Risky asset, and probability
n=1000; x=Random_VarGen(n,'GaussnormI'); x=sort(x(1,:));
figure
h=histogram(x(1,:)); counts=h.Values; total=sum(counts);
probs=counts/total;
% Investment into the risky asset
alpha=250:50:5000; alpha=alpha';
% Number of iterations, and variations in risk aversion
m=10; beta=1/m:1/10:1;
% Storage vector for Expected Utility from each respective iteration of the
% loop
EUS=zeros(m,length(alpha));
% Constructs a graph displaying a variation is risk aversion in an
% indvidual
for p=1:m
    % Wealth States Vector with an static Alpha investmennt
    for i=1:length(x)
    W(1,i)=w0*(1+r)+(alpha(1,1)*(x(1,i)-r));
    end
    % Expected Utility Matrix with an static Alpha Investment
    for i=1:length(probs)
        for j=1:counts(i)
            EU(j,i)= probs(i)*(W(1,i))^(beta(p));
        end
    end
    % Expected Utility with an static alpha investment
    EU=sum(sum(EU));
    % Wealth States Martix with variations in the Alpha investment
    for k=1:length(alpha)
        for l=1:length(x)
            WM(k,l)=w0*(1+r)+(alpha(k,1)*(x(1,l)-r));
        end
    end
    % Expected Unility Array with variations in the Alpha investment
    for m=1:length(probs)
        for n=1:counts(m)
            for o=1:length(alpha)
                EUM(n,m,o)=probs(m)*(WM(o,m))^(beta(p));
            end
        end
    end
    % Expected Utility with variations in the Alpha investment
    EUV=sum(sum(EUM));
    EUVS=reshape(EUV,[length(alpha),1]);
    % The optimal investment in the risky asset

    % Storing the current iterations Expected Utility curve
    EUVS=EUVS';
    EUS(p,:)=EUVS;
    
end

% Plots n iterations
figure
hold on
plot(alpha,EUS(1,:),'DisplayName','x^(1/10)')
title('Expected Utility Curve - Expected Utility against Alpha Investment')
xlabel('Alpha investment into the Risky Asset')
ylabel('Expected Utility')
plot(alpha,EUS(2,:),'DisplayName','x^((2/10))')
plot(alpha,EUS(3,:),'DisplayName','x^((3/10))')
plot(alpha,EUS(4,:),'DisplayName','x^((4/10))')
plot(alpha,EUS(5,:),'DisplayName','x^((5/10))')
plot(alpha,EUS(6,:),'DisplayName','x^((6/10))')
plot(alpha,EUS(7,:),'DisplayName','x^((7/10))')
plot(alpha,EUS(8,:),'DisplayName','x^((8/10))')
plot(alpha,EUS(9,:),'DisplayName','x^((9/10))')
plot(alpha,EUS(10,:),'DisplayName','x^((10/10))')
lgd = legend;
lgd.NumColumns = 3;
hold off


