% Model_1
%
% Purpose: This code is to simulate a portfiolo containing one riskless
% assset, one risky asset. 
% This algorithm models the expected utility of an risk averse
% individual; when presented with one risky asset, and one riskles asset. 
% The model is the simplest, as it only pertains to a risky asset model
% with an IID random variable, with only two possible outcomes for returns.
% The model perfectly performs, and quickly replicated/recreates the 
% Excel stimulation that was presented in ECO 5340: Decision-making Under
% Risk, one day in class.
%
% Note: This model cannot be modified in anyway, as the subsequent subpart
% models, and full model 2 respective subparts. This is due to
% the simplicity of the model, and inability to implement further
% complexity to the model.
% 
% 
% Barry Daemi
% Departmental Distinction Paper
% March 31, 2019
% Southern Methodist University

clear
close all

% Initial Wealth
w0=5000;
% Rate-of-Return of Riskless Asset
r=0.050;
% Rate-of-return of Risky asset, and probability
x1=0.100; p1=0.455; x2=0.010; p2=1-p1;
% Investment into the risky asset
alpha=0:10:5000; alpha=alpha';
% Expected Utility
parfor i=1:length(alpha)
    Eu(i,1)=(p1*log(w0*(1+r)+alpha(i,1)*(x1-r)))+(p2*log(w0*(1+r)+alpha(i,1)*(x2-r)));
end
% The optimal investment in the risky asset
star_alpha = -((w0*(1+r)*(p2*(x2-r)+p1*(x1-r)))/((x2-r)*(x1-r)));

% Plots
figure
plot(alpha,Eu)
title('Expected Utility Curve - Expected Utility against Alpha Investment')
xlabel('Alpha investment into the Risky Asset')
ylabel('Expected Utility')


