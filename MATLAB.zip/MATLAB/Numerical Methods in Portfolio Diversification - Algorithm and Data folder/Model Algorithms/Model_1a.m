% Model_1a
%
% Purpose: This code is to simulate a portfiolo containing one riskless
% assset, one risky asset. 
% This algorithm models the expected utility of an risk averse
% individual; when presented with one risky asset, and one riskles asset. 
% The model could be modified through the Random_VarGen function to base 
% the risky asset variable with vary of different distributions. 
% The model focus is to determine the optimal investment in-between the 
% risky asset, and riskless asset by the risk averse individual.
% 
% 
% Barry Daemi
% Departmental Distinction Paper -
%       Portfolio Diversification - An Introduction to Numerical Methods
% March 31, 2019
% Southern Methodist University

clear
close all

% Initial Wealth
w0=5000;
% Rate-of-Return of Riskless Asset
r=0.050;
% Rate-of-return of Risky asset, and probability
n=1000; x=Random_VarGen2(n,'Gamma'); 
figure
h=histogram(x(1,:),'BinWidth',.2); counts=h.Values; total=sum(counts);
probs=counts/total;
% Investment into the risky asset
alpha=0:10:5000; alpha=alpha';
% Wealth States Vector with an static Alpha investmennt
parfor i=1:length(x)
    W(1,i)=w0*(1+r)+(alpha(1,1)*(x(1,i)-r));
end
% Expected Utility Matrix with an static Alpha Investment
for i=1:length(probs)
    for j=1:counts(i)
        EU(j,i)= probs(i)*log(W(1,i));
    end
end
% Expected Utility with an static alpha investment
%EU=sum(sum(EU));
% Wealth States Martix with variations in the Alpha investment
for k=1:length(alpha)
    for l=1:length(x)
        WM(k,l)=w0*(1+r)+(alpha(k,1)*(x(1,l)-r));
    end
end
% Expected Unility Array with variations in the Alpha investment
for m=1:length(probs)
    for n=1:counts(m)
        for o=1:length(alpha)
            EUM(n,m,o)=probs(m)*log(WM(o,m));
        end
    end
end
% Expected Utility with variations in the Alpha investment
EUV=sum(sum(EUM));
EUVS=reshape(EUV,[length(alpha),1]);
% The optimal investment in the risky asset

% Plots
figure
plot(alpha,EUVS)
title('Expected Utility Curve - Expected Utility against Alpha Investment')
xlabel('Alpha investment into the Risky Asset')
ylabel('Expected Utility')




