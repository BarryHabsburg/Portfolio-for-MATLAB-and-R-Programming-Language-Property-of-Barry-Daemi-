function [X]=Semicircle(n)
X=[];
% parameters
n=n;      % matrix size
t=5000;     % trials
v=[];       % eigenvalue samples
v1=[];      % largest eigenvalue samples
dx=.2;      % binsize
% Experiment
for i=1:t
    % Sample GOE and collect their eigenvalues
    a=randn(n);     % n by n matrix of random 
    s=(a+a')/2;     % symmetrize matrix
    v=[v;eig(s)];   % eigenvalues
    % Sample GUE and collect their largest eigenvalues
    a=randn(n)+sqrt(-1)*randn(n);   % random nxn complex matrix
    s=(a+a')/2;     % Hetmitian matrix
    v1=[v1;max(eig(s))]; % Largest Eigenvalue
end
% Semicular law
v=v/sqrt(n/2);  %normalize eigenvalues
% Plot
[count,x]=hist(v,-2:dx:2);
bar(x,count/(t*n*dx),'y')
% Theory
hold on
plot(x,sqrt(4-x.^2)/(2*pi),'lineWidth',2)
axis([-2.5 2.5 -.1 .5])
hold off
X=x;