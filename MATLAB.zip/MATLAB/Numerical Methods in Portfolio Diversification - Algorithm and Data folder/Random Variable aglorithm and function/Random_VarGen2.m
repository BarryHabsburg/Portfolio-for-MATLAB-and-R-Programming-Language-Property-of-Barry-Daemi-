function [X] = Random_VarGen2(n,string)
% Usage: [X] = Random_VarGen2(n,string)
%
% This routine generates continuous random variables
% with Beta, Gamma, Geometrix Brownian Motion, Guassian Normal(with
% variated-dependence), Guassian Normal (IID), LogNormal, and uniform 
% distributions. 
% 
%
% Inputs:  n                    Number of elements in the Random Variable:
%                               hence, the number of returns generated
%          'String'
%               Beta -          'Beta'
%               Gamma -         'Gamma' 
%                               'Gamma-best'
%               Geometric
%               Brownina
%               Motion -        'Geometric Brownian Motion'
%               Eigenvalue
%               Decomposition
%               Sigma -         'EigenDecompostion-Sigma'
%               Gaussian 
%               Normal 
%               invariate -     'GaussnormI'
%               Gaussian
%               Normal
%               IID -           'The Box-Muller Algorithm - IID Normal'
%                               'The Polar Method Algorithm - IID Normal'
%                               'Inverse Transform Method'
%               Gaussian
%               Normal
%               Correlated -    'GaussnormCorr'
%               Log-
%               normal -        'Lognormal' - in-work-at-moment
%               Uniform -       'Uniform'
%                               
%                               
%                               
% Outputs: X                    Generated random variable
%

Distribution = string;

switch Distribution
    case 'Beta'
        
        alpha=0.5; beta=0.5;
        Y1=gamrnd(alpha,1,[n,n]);
        Y2=gamrnd(beta,1,[n,n]);
        X1=Y1/(Y1+Y2);
        Y1=gamrnd(alpha,1,[n,n]);
        Y2=gamrnd(beta,1,[n,n]);
        X2=Y1/(Y1+Y2);
        
        figure 
        hold on
        histogram(X1(1,:),'Normalization','probability')
        histogram(X2(1,:),'Normalization','probability')
        hold off

        s=2;
        mu=zeros(1,s);

        mu(1,1)=mean(X1(1,:));
        mu(1,2)=mean(X2(1,:));
        Sigma=cov(X1(1,:),X2(1,:));

        figure
        x1=-3:.2:3; x2=-3:.2:3;
        [X1,X2]=meshgrid(x1,x2);
        F=mvnpdf([X1(:) X2(:)],mu,Sigma);
        F=reshape(F,length(x2),length(x1));
        surf(x1,x2,F);
        caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
        axis([-3 3 -3 3 0 .4])
        xlabel('x1'); ylabel('x2'); zlabel('Probability Density');
        
        X=[X1,X2];

    case 'Beta - Beta(alpha,alpha)'
        
        u=n;
        U1=rand(1,u);
        U2=rand(1,u);
        X=(1/2).*(1+sqrt(1-U1.^(2/(2*2-1))).*cos(2*pi.*U2));

        U1=rand(1,u);
        U2=rand(1,u);
        Y=(1/2).*(1+sqrt(1-U1.^(2/(2*2-1))).*cos(2*pi.*U2));

        figure 
        hold on
        histogram(X,'Normalization','probability')
        histogram(Y,'Normalization','probability')
        hold off

        s=2;
        mu=zeros(1,s);

        mu(1,1)=mean(X);
        mu(1,2)=mean(Y);
        Sigma=cov(X,Y);

        figure
        x1=-3:.2:3; x2=-3:.2:3;
        [X1,X2]=meshgrid(x1,x2);
        F=mvnpdf([X1(:) X2(:)],mu,Sigma);
        F=reshape(F,length(x2),length(x1));
        surf(x1,x2,F);
        caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
        axis([-3 3 -3 3 0 .4])
        xlabel('x1'); ylabel('x2'); zlabel('Probability Density');

        X=[X;Y];
        
    case 'Beta - Arcsine Generator'
        
        U=rand(1,n);
        X=(cos(pi.*(U/2))).^(2);
        U=rand(1,n);
        Y=(cos(pi.*(U/2))).^(2);

        figure 
        hold on
        histogram(X,'Normalization','probability')
        histogram(Y,'Normalization','probability')
        hold off

        s=2;
        mu=zeros(1,s);

        mu(1,1)=mean(X);
        mu(1,2)=mean(Y);
        Sigma=cov(X,Y);

        figure
        x1=-3:.2:3; x2=-3:.2:3;
        [X1,X2]=meshgrid(x1,x2);
        F=mvnpdf([X1(:) X2(:)],mu,Sigma);
        F=reshape(F,length(x2),length(x1));
        surf(x1,x2,F);
        caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
        axis([-3 3 -3 3 0 .4])
        xlabel('x1'); ylabel('x2'); zlabel('Probability Density');

        X=[X;Y];
        
    case 'Gamma'
        
        lambda=10;
        U1=rand(n,1);
        X(1,:)=-(1/lambda)*log(U1(1:n));
        U2=rand(n,1);
        Y(1,:)=-(1/lambda)*log(U2(1:n));

        figure 
        hold on
        histogram(X,'Normalization','probability')
        histogram(Y,'Normalization','probability')
        hold off

        % fix me
        figure
        hold on 
        Y2(:,1)=sort(X);
        norm=normpdf(Y2,mean(Y2),std(Y2));
        plot(Y2,norm);
        Y3(:,1)=sort(Y);
        norm=normpdf(Y3,mean(Y3),std(Y3));
        plot(Y3,norm);     
        hold off
        
        s=2;
        mu=zeros(1,s);

        mu(1,1)=mean(X);
        mu(1,2)=mean(Y);
        Sigma=cov(X,Y);

        figure
        x1=-3:.2:3; x2=-3:.2:3;
        [X1,X2]=meshgrid(x1,x2);
        F=mvnpdf([X1(:) X2(:)],mu,Sigma);
        F=reshape(F,length(x2),length(x1));
        surf(x1,x2,F);
        caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
        axis([-3 3 -3 3 0 .4])
        xlabel('x1'); ylabel('x2'); zlabel('Probability Density');

        X=[X;Y];

    case 'Gamma-best'
        
        % gamma_best.m
        N=n; alpha=0.3;
        d=0.07+0.75*sqrt(1-alpha); b=1+exp(-d)*alpha;
        x=zeros(N,1);

        for i=1:N
            cont=true;
            while (cont)
                U1=rand;
                U2=rand;
                V=b*U1;
                if(V<=1)
                    X=d*V^(1/alpha);
                    if(U2<=(2-X)/(2+X))
                        cont=false; break;
                    else
                        if(U2<=exp(-X))
                            cont=true;
                        end
                    end
                end
            end
            x(i)=X;
        end

        y=zeros(N,1);
        for i=1:N
            cont=true;
            while (cont)
                U3=rand;
                U4=rand;
                V=b*U3;
                if(V<=1)
                    Y=d*V^(1/alpha);
                    if(U4<=(2-Y)/(2+Y))
                        cont=false; break;
                    else
                        if(U4<=exp(-Y))
                            cont=true;
                        end
                    end
                end
            end
            y(i)=Y;
        end

        x=x'; y=y';
        X=[x;y];
        
    case 'Geometric Brownian Motion'
        
        T=1; % final time
        n=n; h=T/(n-1); t=0:h:T;
        mu=1; sigma=0.2; x0=1; % parameters
        W=sqrt(h)*[0,cumsum(randn(1,n-1))];
        x1=x0*exp((mu-sigma^2/2)*t+sigma*W);
        figure
        plot(t,x1)
        hold on
        plot(t,exp(mu*t),'r'); % plot exact mean function
        hold off

        figure
        X1=sort(x1);
        histogram(X1)
        
        T1=1; % final time
        n1=n; h1=T1/(n-1); t1=0:h1:T1;
        mu1=1; sigma1=0.2; x10=1; % parameters
        W1=sqrt(h1)*[0,cumsum(randn(1,n-1))];
        x2=x0*exp((mu1-sigma1^2/2)*t1+sigma1*W1);
        figure
        plot(t1,x2)
        hold on
        plot(t1,exp(mu1*t1),'r'); % plot exact mean function
        hold off

        figure
        X2=sort(x2);
        histogram(X2)
        
        X=[x1;x2];
        
    case 'Brownian Motion'
        
        h=0.001;
        x=[0:h:1]; % Think of h as "Delta x"
        dW1=randn(length(x),1)*sqrt(h); % Think sqrt(Delta x)
        W1=cumsum(dW1);
        hold on
        plot(x,W1)
        
        dW2=randn(length(x),1)*sqrt(h); % Think sqrt(Delta x)
        W2=cumsum(dW2);
        plot(x,W2)
        
        W1=W1'; W2=W2';
        X=[W1;W2];
        hold off
        
        
    case 'The Box-Muller Algorithm - IID Normal'
        
        u = n;
        U1 = rand(1,u);
        U2 = rand(1,u);
        X=sqrt(-2.*log(U1)).*cos(2.*pi.*U2); Y=sqrt(-2.*log(U1)).*sin(2.*pi.*U2);
        
        figure 
        hold on
        histogram(X,'Normalization','probability')
        histogram(Y,'Normalization','probability')
        hold off
        
        % fix me
        figure
        hold on
        Y2(:,1) = sort(X);
        norm = normpdf(Y2,mean(Y2),std(Y2));
        plot(Y2,norm);
        Y3(:,1) = sort(Y);
        norm = normpdf(Y3,mean(Y3),std(Y3));
        plot(Y3,norm);     
        hold off
        
        s=2;
        mu = zeros(1,s);
        
        mu(1,1) = mean(X);
        mu(1,2) = mean(Y);
        Sigma = cov(X,Y);
        
        figure
        x1 = -3:.2:3; x2 = -3:.2:3;
        [X1,X2] = meshgrid(x1,x2);
        F = mvnpdf([X1(:) X2(:)],mu,Sigma);
        F = reshape(F,length(x2),length(x1));
        surf(x1,x2,F);
        caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
        axis([-3 3 -3 3 0 .4])
        xlabel('x1'); ylabel('x2'); zlabel('Probability Density');
        
        X=[X;Y];
        
    case 'The Polar Method Algorithm - IID Normal'
        
        u=n;
        U1=rand(u,1);
        U2=rand(u,1);
        X=sqrt(-2.*log(U1)).*cos(2.*pi.*U2); 
        Y=sqrt(-2.*log(U1)).*sin(2.*pi.*U2);
        
        figure 
        hold on
        histogram(X,'Normalization','probability')
        histogram(Y,'Normalization','probability')
        hold off
        
        % fix me
        figure
        hold on
        Y2(:,1) = sort(X);
        norm = normpdf(Y2,mean(Y2),std(Y2));
        plot(Y2,norm);
        Y3(:,1) = sort(Y);
        norm = normpdf(Y3,mean(Y3),std(Y3));
        plot(Y3,norm);     
        hold off
        
        s=2;
        mu = zeros(1,s);
        
        mu(1,1) = mean(X);
        mu(1,2) = mean(Y);
        Sigma = cov(X,Y);
        
        figure
        x1 = -3:.2:3; x2 = -3:.2:3;
        [X1,X2] = meshgrid(x1,x2);
        F = mvnpdf([X1(:) X2(:)],mu,Sigma);
        F = reshape(F,length(x2),length(x1));
        surf(x1,x2,F);
        caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
        axis([-3 3 -3 3 0 .4])
        xlabel('x1'); ylabel('x2'); zlabel('Probability Density');
   
        X=[X;Y];
        
    case 'GaussnormIID'
        
        A=[1 0;0 1];
        [R,Error] = Cholesky_Factorization(A);
        Z=randn(2,n);
        X=R'*Z;
        
        figure 
        hold on
        histogram(X(1,:),'Normalization','probability')
        histogram(X(2,:),'Normalization','probability')
        hold off
    
        % fix me
        figure
        hold on
        Y2(:,1) = sort(X(2,:));
        norm = normpdf(Y2,mean(Y2),std(Y2));
        plot(Y2,norm);
        Y(:,1) = sort(X(1,:));
        norm = normpdf(Y,mean(Y),std(Y));
        plot(Y,norm);     
        hold off
    
        s=2;
        mu = zeros(1,s);
        mu(1,1) = mean(X(1,:)); mu(1,2) = mean(X(2,:));
        sigma=cov(X(1,:),X(2,:));
    
        figure
        x1 = -3:.2:3; x2 = -3:.2:3;
        [X1,X2] = meshgrid(x1,x2);
        F = mvnpdf([X1(:) X2(:)],mu,sigma);
        F = reshape(F,length(x2),length(x1));
        surf(x1,x2,F);
        caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
        axis([-3 3 -3 3 0 .4])
        xlabel('x1'); ylabel('x2'); zlabel('Probability Density');
        
    case 'GaussnormI'
        
        Z0=randn(2,2);
        Z0=Z0*Z0';
    
        [C0,Error] = Cholesky_Factorization(Z0);
    
        sigma=C0'*C0;
        X0=C0'*Z0;
    
        [C,Error] = Cholesky_Factorization(sigma);
        Z=randn(2,n);
        X=C'*Z;
    
        figure 
        hold on
        histogram(X(1,:),'Normalization','probability')
        histogram(X(2,:),'Normalization','probability')
        hold off
    
        % fix me
        figure
        hold on
        Y2(:,1) = sort(X(2,:));
        norm = normpdf(Y2,mean(Y2),std(Y2));
        plot(Y2,norm);
        Y(:,1) = sort(X(1,:));
        norm = normpdf(Y,mean(Y),std(Y));
        plot(Y,norm);     
        hold off
    
        s=2;
        mu = zeros(1,s);
        mu(1,1) = mean(X(1,:)); mu(1,2) = mean(X(2,:));
    
        figure
        x1 = -3:.2:3; x2 = -3:.2:3;
        [X1,X2] = meshgrid(x1,x2);
        F = mvnpdf([X1(:) X2(:)],mu,sigma);
        F = reshape(F,length(x2),length(x1));
        surf(x1,x2,F);
        caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
        axis([-3 3 -3 3 0 .4])
        xlabel('x1'); ylabel('x2'); zlabel('Probability Density');
        
    case 'GaussnormCorr'
        
        A=[2 1.9888; 1.9888 2];
        [R,Error] = Cholesky_Factorization(A);
        Z1=randn(2,n);
        X=R'*Z1;
        
        figure 
        hold on
        histogram(X(1,:),'Normalization','probability')
        histogram(X(2,:),'Normalization','probability')
        hold off
    
        % fix me
        figure
        hold on
        Y2(:,1) = sort(X(2,:));
        norm = normpdf(Y2,mean(Y2),std(Y2));
        plot(Y2,norm);
        Y(:,1) = sort(X(1,:));
        norm = normpdf(Y,mean(Y),std(Y));
        plot(Y,norm);     
        hold off
    
        s=2;
        mu = zeros(1,s);
        mu(1,1) = mean(X(1,:)); mu(1,2) = mean(X(2,:));
        sigma=cov(X(1,:),X(2,:));
    
        figure
        x1 = -3:.2:3; x2 = -3:.2:3;
        [X1,X2] = meshgrid(x1,x2);
        F = mvnpdf([X1(:) X2(:)],mu,sigma);
        F = reshape(F,length(x2),length(x1));
        surf(x1,x2,F);
        caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
        axis([-3 3 -3 3 0 .4])
        xlabel('x1'); ylabel('x2'); zlabel('Probability Density');
        
    case 'GaussnormCorr2'
        
        Z=zeros(2,n);
        mu1=[0 0]; sigma1=[1 0;0 1];
        Z=mvnrnd(mu1,sigma1,n)';
        A=[2 1.988; 1.988 2];
        [R,Error] = Cholesky_Factorization(A);
        X=R'*Z;
    
        figure 
        hold on
        histogram(X(1,:),'Normalization','probability')
        histogram(X(2,:),'Normalization','probability')
        hold off
     
        hold off
    
        s=2;
        mu = zeros(1,s);
        mu(1,1) = mean(X(1,:)); mu(1,2) = mean(X(2,:));
        sigma=cov(X(1,:),X(2,:));
    
        figure
        x1 = -3:.2:3; x2 = -3:.2:3;
        [X1,X2] = meshgrid(x1,x2);
        F = mvnpdf([X1(:) X2(:)],mu,sigma);
        F = reshape(F,length(x2),length(x1));
        surf(x1,x2,F);
        caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
        axis([-3 3 -3 3 0 .4])
        xlabel('x1'); ylabel('x2'); zlabel('Probability Density');
        X=X;
        
    case 'EigenDecompostion-Sigma'
        
        Z0=randn(2,2);
        sigma=Z0'*Z0;
        [V,D]=eig(sigma);
        u=n;
        Z=rand(1,u); Z=rand(2,u);
        X=1+(V*sqrt(D)*Z);

        figure 
        hold on
        histogram(X(1,:),'Normalization','probability')
        histogram(X(2,:),'Normalization','probability')
        hold off

        % fix me
        figure
        hold on
        Y2(:,1) = sort(X(2,:));
        norm = normpdf(Y2,mean(Y2),std(Y2));
        plot(Y2,norm);
        Y(:,1) = sort(X(1,:));
        norm = normpdf(Y,mean(Y),std(Y));
        plot(Y,norm);     
        hold off
        
        s=2;
        mu = zeros(1,s);
        mu(1,1) = mean(X(1,:)); mu(1,2) = mean(X(2,:));
        
        figure
        x1 = -3:.2:3; x2 = -3:.2:3;
        [X1,X2] = meshgrid(x1,x2);
        F = mvnpdf([X1(:) X2(:)],mu,sigma);
        F = reshape(F,length(x2),length(x1));
        surf(x1,x2,F)
        caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
        axis([-3 3 -3 3 0 .4])
        xlabel('x1'); ylabel('x2'); zlabel('Probability Density');
        
    case 'Inverse Transform Method'
        
        u=n;
        U1=rand(u,1);
        U2=rand(u,1);
        t=-log(U1.*U2);
        U3=rand(u,1);
        X1=t.*U3; Y=t-X1; 
        X1=X1';  Y=Y';
        
        figure 
        hold on
        histogram(X1,'Normalization','probability')
        histogram(Y,'Normalization','probability')
        hold off

        % fix me
        figure
        hold on
        Y1=zeros(1,length(X1)); Y2=zeros(1,length(Y));
        Y1(1,:) = sort(X1);
        norm = normpdf(Y1,mean(Y1),std(Y1));
        plot(Y1,norm);
        Y2(1,:) = sort(Y);
        norm = normpdf(Y2,mean(Y2),std(Y2));
        plot(Y2,norm);     
        hold off
        
        X=[X1;Y]; 
        
    case 'Lognormal'
        
        U=normrnd(0,1/4,[1,n]);
        X3=exp(U);
        U1=normrnd(0,1/4,[1,n]);
        X4=exp(U1);
        
        figure 
        hold on
        histogram(X3,'Normalization','probability')
        histogram(X4,'Normalization','probability')
        hold off
    
        % fix me
        figure
        hold on
        Y(:,1) = sort(X3);
        norm = normpdf(Y,mean(Y),std(Y));
        plot(Y,norm);   
        Y2(:,1) = sort(X4);
        norm = normpdf(Y2,mean(Y2),std(Y2));
        plot(Y2,norm);  
        hold off
    
        s=2;
        mu = zeros(1,s);
        mu(1,1) = mean(X3); mu(1,2) = mean(X4);
        sigma=cov(X3,X4);
    
        figure
        x1 = -3:.2:3; x2 = -3:.2:3;
        [X1,X2] = meshgrid(x1,x2);
        F = mvnpdf([X1(:) X2(:)],mu,sigma);
        F = reshape(F,length(x2),length(x1));
        surf(x1,x2,F);
        caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
        axis([-3 3 -3 3 0 .4])
        xlabel('x1'); ylabel('x2'); zlabel('Probability Density');
        
        X=[X3;X4];
        
        
    case 'Uniform'
        
        u=n;
        a=-4; b=4;
        U=rand(1,u);
        X3=[a+(b+1-a)*U];
        
        u=n;
        a=-4; b=4;
        U1=rand(1,u);
        Y=[a+(b+1-a)*U1];
        
        figure 
        hold on
        histogram(X3,'Normalization','probability')
        histogram(Y,'Normalization','probability')
        hold off

        % fix me
        figure
        hold on
        Y2(:,1) = sort(X3);
        norm = normpdf(Y2,mean(Y2),std(Y2));
        plot(Y2,norm);
        Y3(:,1) = sort(Y);
        norm = normpdf(Y3,mean(Y3),std(Y3));
        plot(Y3,norm);     
        hold off
        
        s=2;
        mu = zeros(1,s);
        
        mu(1,1) = mean(X3);
        mu(1,2) = mean(Y);
        Sigma = cov(X3,Y);
        
        figure
        x1 = -3:.2:3; x2 = -3:.2:3;
        [X1,X2] = meshgrid(x1,x2);
        F = mvnpdf([X1(:) X2(:)],mu,Sigma);
        F = reshape(F,length(x2),length(x1));
        surf(x1,x2,F);
        caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
        axis([-3 3 -3 3 0 .4])
        xlabel('x1'); ylabel('x2'); zlabel('Probability Density');
        
        X=[X3;Y];
        
        % Make a uniform case, based around MATLAB's rand function
    
    case 'Uniform2'
        
        u=n;
        U=rand(1,u);
        X3=U;
        U1=rand(1,u);
        Y=U1;
        
        figure 
        hold on
        histogram(X3)
        histogram(Y)
        hold off

        % fix me
        figure
        hold on
        Y2(:,1) = sort(X3);
        norm = normpdf(Y2,mean(Y2),std(Y2));
        plot(Y2,norm);
        Y3(:,1) = sort(Y);
        norm = normpdf(Y3,mean(Y3),std(Y3));
        plot(Y3,norm);     
        hold off
        
        s=2;
        mu = zeros(1,s);
        
        mu(1,1) = mean(X3);
        mu(1,2) = mean(Y);
        Sigma = cov(X3,Y);
        
        figure
        x1 = -3:.2:3; x2 = -3:.2:3;
        [X1,X2] = meshgrid(x1,x2);
        F = mvnpdf([X1(:) X2(:)],mu,Sigma);
        F = reshape(F,length(x2),length(x1));
        surf(x1,x2,F);
        caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
        axis([-3 3 -3 3 0 .4])
        xlabel('x1'); ylabel('x2'); zlabel('Probability Density');
        
        X=[X3;Y];
        
    case 'Semicircle'
        
        [X1]=Semicircle(n);
        [X2]=Semicircle(n);
        
        X=[X1;X2];

     
end

end
    