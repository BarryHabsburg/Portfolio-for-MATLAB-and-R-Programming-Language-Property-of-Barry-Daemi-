% Brownian Motion algorithm from Random Matrix Theory, Numerical Computation
% and Application
clear
close all
n=1000;
X0=50; X1=120;
h=(X1-X0)/n;
X=X0:h:X1
% Think of h as "Delta x"
dW=randn(length(X),1)*sqrt(h); % Think sqrt(Delta x)
W=cumsum(dW);
plot(X,W)

figure
histogram(X)

% Add this into Brownian motion subsection