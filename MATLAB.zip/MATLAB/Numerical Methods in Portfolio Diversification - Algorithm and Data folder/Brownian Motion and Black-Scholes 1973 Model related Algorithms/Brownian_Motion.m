% Brownian Motion algorithm from Random Matrix Theory, Numerical Computation
% and Application
clear
close all
h=0.00001;
x=[0:h:5]; % Think of h as "Delta x"
dW=randn(length(x),1)*sqrt(h); % Think sqrt(Delta x)
W=cumsum(dW);
plot(x,W)

figure
histogram(x)