% Black-Scholes Solution from Stven R. Dunbar, 
% University of Nebraska-Lincoln
clear
close all

% Parameters
m=6; n=61; S0=70; S1=130; K=100;
r=0.12; T=1.0; sigma=0.10;
time=linspace(T,0,m)';
S=linspace(S0,S1,n);
d1=(log(S/K)+((r+sigma^2/2)*(T-time)))./(sigma*sqrt(T-time));
d2=(log(S/K)+((r-sigma^2/2)*(T-time)))./(sigma*sqrt(T-time));
part1=bsxfun(@times,normcdf(d1),S);
part2=bsxfun(@times,K*exp(-r*(T-time)),normcdf(d2));
VC=part1-part2;
plot(S,VC)