% Example script for Black-Scholes noncontinuous solution from the
% Black-Scholes (1973) publication. The example scripts models European
% Options based from a stock price ranged from 50 to 120 USD, with a time
% interval step of (-T/m), and stock interval step of (X1-X0)/(n-1).  
% 
% Barry Daemi
% Departmental Distinction Paper -
%       Portfolio Diversification - An Introduction to Numerical Methods
% March 31, 2019
% Southern Methodist University
clear
close all

% Number of times, and valuation steps in Stock Price, and {a,b] for Stock Price
n=90; m=8; X0=50; X1=120;   
% Maturity date of the European Option
T=1.0;
% Excercise price for the European Option
K=95;
% Standard deviation of the stock (stochastic asset)
sigma=0.08;
% Return on the equity in the hedged position
r=0.15; 
% Interval of time: T:-T/m:0
t=(T:-T/m:0)';
% Interval for Stock Value
X=X0:(X1-X0)/(n-1):X1;
% Input One in NormCDF for EQ1
d1=(log(X/K)+((r+(1/2)*sigma^(2))*(T-t)))./(sigma*sqrt(T-t));
% Input Two in NormCDF for EQ2
d2=(log(X/K)+((r-(1/2)*sigma^(2))*(T-t)))./(sigma*sqrt(T-t));
% EQ1 of the solution
EQ1=bsxfun(@times,X,normcdf(d1));
% EQ2 of the solution
EQ2=bsxfun(@times,K*exp(-r*(T-t)),normcdf(d2));
% Complete Solution of Black-Scholes PDE
V=EQ1-EQ2;
% plot3(X,t,V)
plot(X,V)
title('Option Price against Stock Price')
xlabel('Stock Price')
ylabel('Option Price')



