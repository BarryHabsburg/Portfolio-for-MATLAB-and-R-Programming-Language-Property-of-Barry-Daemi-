% Homework #3
%
% Purpose: This program was designed to simulate the Standard Map for  
% an nth quantity of initial conditions, along with nth quantity of phase
% shifts. The Code(11.1 M-File for fig. 2.1 and Figs. 2.2) was originally 
% created by Connor Fin, who authored the following paper titled: 
% Chaotic Control Theory Applied to the Chirikov Standard Map. 
% The code was sequently modified by myself to answer the homework
% 
% Barry Daemi
% MATH 6325
% March 31, 2019
% Southern Methodist University

clear all 

% This can be changed to select the required k value
k = 0.5;

% Number of initial conditions generated for each phase shift
for i=1:1000
    q(1,i)=rand;
    p(1,i)=rand;
    for j=2:5000
        % We can add in some phase shift there to focus the plot
        % to where we want
        q(j,i)=mod(((q(j-1,i))+p(j-1,i)),1);
        p(j,i)=mod((p(j-1,i)+(k/(2*pi))*sin(2*pi*q(j,i))),1);
    end
end

scrsz=get(0,'ScreenSize');
set(0,'DefaultFigurePosition',[scrsz(1) scrsz(2) scrsz(3) scrsz(4)]);

plot(q,p,'.','MarkerSize',1)

axis([0 1 0 1])
box on
title(['k=',num2str(k)]);
set(gca,'XTick',0:0.25:1)
set(gca,'YTick',0:0.25:1)
set(gca,'XTickLabel',{'0','pi/2','pi','3pi/2','2pi'})
set(gca,'YTickLabel',{'0','pi/2','pi','3pi/2','2pi'})
xlabel(['{theta}' 'mod{2pi)']);
ylabel(['q mod' '(2pi)']);
axis square
