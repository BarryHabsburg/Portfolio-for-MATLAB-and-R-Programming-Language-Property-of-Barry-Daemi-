% Problem 1.5 from Intro. to Numerical Analysis by Endre Suli and David
% Mayers
% Author: Barry Daemi
% Math 6317: Numerical Methods II
% Southern Methodist University
% Spring 2021

clear
close all, close all

% Sets the root function
f=@(x)exp(x)-x-1.000000005;

% Sets the root function derivative
df=@(x)exp(x)-1;

% Initial guess and max iteration
x0=0.75; maxit=10000;

% Desired Tolerence level for the approximation
tol=10^-7;

% Execution of Newton's Method Function
[zero,res,Iter] = NewtonIter(f, df, x0, maxit, tol);





