% Problem 4.2 from Intro. to Numerical Analysis by Endre Suli and David
% Mayers
% Author: Barry Daemi
% Math 6317: Numerical Methods II
% Southern Methodist University
% Spring 2021

clear
close all, close all

% Constants for the model
lamda=5; delta=1;

% The nonzero x-value solution - this was derived by hand-calculations
x=9/4;

% Root-finding functions
f=@(y)lamda*x*y-x*(1+y);
f1=@(y)y.^(2)-2.*delta*y+1-x.*y;

% Derivatives of the root-finding functions
df=@(y)9;
df1=@(y)2*y-(17/4);

% Initial guess and max iteration
y0=0.75; maxit=10000;

% Desired Tolerence level for the approximation
tol=10^-10;

% Executes Newtons Method
[zero,res,Iter] = NewtonIter2(f,df,y0,maxit,tol);

% Desired Tolerence level for the approximation
tol=10^-10;

% Executes Newtons Method
[zero,res,Iter] = NewtonIter2(f1,df1,y0,maxit,tol);

% Create the variables needed to plot the system of equations
y=-5:0.01:5; z=f(y); z2=f1(y);

% Plots the system of equations for the nonzero x solution
figure (1)
plot(y,z)
hold on
grid on
grid minor
plot(y,z2)
xlabel('x values'), ylabel('y values'), 
title('Bioremediation System of Equations')
hold off

% The zero x-value solution - this was derived by hand-calculations
x=0;

% Root-finding functions
f2=@(y)lamda*x*y-x*(1+y); % Note this function is zero in this case
f3=@(y)y.^(2)-2.*delta*y+1-x.*y; % Note function y^(2)-2y+1;

% Derivative of the single root-finding functions
df1=@(y)2*y-2;

% Create the variables needed to plot the system of equations
z=f2(y); z3=f1(y);

% Executes Newtons Method
[zero,res,Iter] = NewtonIter2(f3,df1,y0,maxit,tol);

% Plots the system of equations for the nonzero x solution
figure (2)
hold on
plot(y,z)
grid on
grid minor
plot(y,z2)
xlabel('x values'), ylabel('y values'), 
title('Bioremediation System of Equations')
hold off

