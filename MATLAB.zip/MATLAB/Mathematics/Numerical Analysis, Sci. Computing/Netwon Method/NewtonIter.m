function [zero,res,Iter] = NewtonIter(f,df,x0,maxit,tol,varargin)   
% Usage: [zero,res,Iter] = NewtonIter(f,df,x0,maxit,tol,varargin)
%
% This routine solves the scalar-valued nonlinear equation f(x)=0 
% using Newton's method to a tolerance of tol.

% Evaluates f with initial condition x0
x=x0; fx=f(x,varargin{:}); dfx=df(x,varargin{:});
Iter=0; diff=tol+1;

% Control statements for function
if(class(f)~='function_handle')
    fprintf(['f class type must be a function handle, and no',... 
        'otherclass class type.']);
elseif(class(df)~='function_handle')
    fprintf(['df''s class type must be a function handle, and',...
        'no other class type.']);
elseif(class(x0)~='double')
    fprintf(['x0''s class type must be a double, and no other',...
        'class type.']);
elseif(class(maxit)~='double')
    fprintf(['maxit''s class type must be a double, and no other',...
        'class type.']);
elseif(class(tol)~='double')
    fprintf(['tol''s class type must be a double, and no other',...
        'class type.']);
elseif (tol<eps)
    fprintf(['Inputted tolerance exceeded machine epsilon, and',... 
        'therefore was scaled by 100']);
    tol=tol*100;
elseif (maxit<1)
    fprintf(['Maxit must be a positive integer that is greater',... 
        'than 1.\n Therefore maxit was replaced by 10']);
    maxit=10;
elseif(abs(fx)<tol)
    fprintf(['The initial guess x0 is the root/fixed point,',...
        'and therefore is the solution to the problem']);
    zero=x0;
    res=fx;
    Iter=0;
    return
end

% Mapping of the function to a plot
x2=-3:0.01:3; y=f(x2); plot(x2,y), hold on
grid on, grid minor
title('Plot of F with Newton Method')
xlabel('-3 < x < 3') 
ylabel('Y values of F') 
% Mapping the first derivative in respect of the initial guess x0
x3=x:0.01:3; y1=dfx*x3; plot(x3,y1)

% Newton's Method
while(diff>=tol&&Iter<maxit)
    Iter=Iter+1; diff=-fx/dfx;
    x=x+diff;    diff=abs(diff);
    fx=f(x,varargin{:}); dfx=df(x,varargin{:});
    x3=x:0.01:3; y1=dfx*x3; plot(x3,y1)
end

% Failure message for Newton's Method
if(Iter==maxit&&diff>tol)
    fprintf("Newton's Method did not convergence under max iteration.");
end

% Two of the return values of Newton's Method
zero=x; res=fx;

fprintf('Newton''s Method has converged!\n')
fprintf(' X = %22.16e, Iter = %3i\n', x, Iter)
fprintf(' Tol = %22.16e, fx = %9.3e\n', tol, fx)
end



    



