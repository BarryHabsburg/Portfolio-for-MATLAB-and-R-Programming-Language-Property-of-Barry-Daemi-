function [In,n,Ntot] = adaptive_int(f,a,b,rtol,atol)
% Usage: [Iappr,n,Ntot] = adaptive_int(f,a,b,rtol,atol)
%
% This routine numerically approximates the integral
%    int_a^b f(x) dx
% using the composite Gaussian quadrature rule using 4 points per
% interval (i.e. O(h^8) accurate) over n, m subintervals. We require
% that f have the calling syntax 
%    y = f(x)
% where y has the same size and shape as x, in the case 
% that x is array-valued.
%
% Inputs:  f      function to integrate
%          a      left end point of integration
%          b      right end point of integration
%          rtol   relative tolerance
%          atol   absolute tolerance
%                 
% Outputs: In     value of the numerical integral
%          n      final number of subintervals to determine In
%          Ntot   accumulated total of all integrand evaluations required
%                 to determined a final solution

% Barry Daemi
% Math3315 / CSE3365
% Spring 2018

% sets the value to Ntot
Ntot = 0;

% sets the value to n
n = 2;

% sets the value to m
m = 3;

% determines In from the set n intervals
[In,nf] = composite_Gauss4(f,a,b,n);
Ntot = Ntot + nf;

% determines Im from the set m intervals
[Im,nf] = composite_Gauss4(f,a,b,m);
Ntot = Ntot + nf;

% Boolean Statement: Breakout/Return - determined by rtol, atol condition
if( abs(Im - In) < rtol*abs(Im)+atol)
    return;
end


% iterates over many subintervals
for i = 1:100000000000
    n = n*2;
    m = m*2;
    [In,nf] = composite_Gauss4(f,a,b,n);
    Ntot = Ntot + nf;

    [Im,nf] = composite_Gauss4(f,a,b,m);
    Ntot = Ntot + nf;
    
    % Reference above: early breakout of for loop, when condition is met
    if( abs(Im - In) < rtol*abs(Im)+atol)
        return;
    end

end

% end of function
