% test_adapt
%
% Purpose:  The file is set up, to test adaptive_int, and
% determinate the functionality of the quadature function, in
% approximating a numerical solution to a example integral.
%
% Barry Daemi
% Math 3315 / CSE 3365
% Spring 2018

clear

% sets the function parameters
c = 2;
d = 3;

% sets the integrand
f = @(x) exp(c*x) + sin(d*x);

% sets the true numerical solution to integral
a = -5; 
b = 4;
Itrue = 1/c*(exp(c*b) - exp(c*a)) - 1/d*(cos(d*b)-cos(d*a));
fprintf('\nTrue I = %16.10e\n',Itrue)

% sets the value of rtol
rtol = [ 0.01 0.0001 0.000001 0.00000001 0.0000000001 0.000000000001];

% sets the value of atol
atol = [ 10^-5 10^-7 10^-9 10^-11 10^-13 10^-15 ];

fprintf('\nGauss-4:\n')
fprintf('--------------------------------------------------\n')

% tests the method and stores the results
for i = 1:length(rtol)
   
   % Adaptive_int
   [In,n,Ntot] = adaptive_int(f,a,b,rtol(i),atol(i));
   fprintf('  In = %22.16e,  n = %3i, Ntot = %3i\n', In, n, Ntot)
   
   fprintf(' rtol = %22.16e, atol = %9.3e\n', rtol(i), atol(i))
   fprintf('--------------------------------------------------\n')

end