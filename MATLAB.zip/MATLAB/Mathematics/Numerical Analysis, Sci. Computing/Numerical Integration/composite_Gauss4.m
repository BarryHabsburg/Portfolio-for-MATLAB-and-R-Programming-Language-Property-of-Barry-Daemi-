function [F,nf] = composite_Gauss4(f,a,b,n)
% Usage: [F,nf] = composite_Gauss4(f,a,b,n)
%
% This routine numerically approximates the integral
%    int_a^b f(x) dx
% using the composite Gaussian quadrature rule using 4 points per
% interval (i.e. O(h^8) accurate) over n subintervals. We require
% that f have the calling syntax 
%    y = f(x)
% where y has the same size and shape as x, in the case 
% that x is array-valued.
%
% Inputs:  f      function to integrate
%          a      left end point of integration
%          b      right end point of integration
%          n      number of subintervals
%
% Outputs: F      value of the numerical integral
%          nf     number of evaluation points for f
%
% Barry Daemi
% Math3315
% Spring 2018

% check inputs
if (b < a) 
   error('composite_Gauss4 error: b < a!');
end
if (n < 1) 
   error('composite_Gauss4 error: n < 1!');
end

% set up subinterval partition and width
xvals = linspace(a,b,n+1);
h = (b-a)/n;

% set nodes/weights defining the quadrature method
base_nodes = [-sqrt((3-4*sqrt(0.3))/7),
              -sqrt((3+4*sqrt(0.3))/7),
               sqrt((3-4*sqrt(0.3))/7),
               sqrt((3+4*sqrt(0.3))/7)];
weights = h/2*[1/2 + sqrt(10/3)/12,
               1/2 - sqrt(10/3)/12,
               1/2 + sqrt(10/3)/12,
               1/2 - sqrt(10/3)/12];

% initialize results
F = 0;
nf = 4*n;

% iterate over subintervals
for i=1:n

   % determine evaluation points within subinterval
   nodes = (xvals(i) + xvals(i+1))/2 + h/2*base_nodes;
   
   % evaluate function at nodes within subinterval
   fvals = f(nodes);
   
   % add approximation on this subinterval to result
   F = F + sum(weights.*fvals);

end

% end of function