% Tester program for root_finder.m
%
% 

clear

sigma = 5.67e-8;
epsilon = 0.78;
h = 20;
T8 = 310;
Ts = T8;
D = 0.3;
I2R = 150;

f = @(T) T8 + (I2R/(D*h*pi)) - ((epsilon*sigma)/h)*(T.^(4)-Ts.^(4)); 

% Allow a maximum of 20 iterations

maxit = 30;

% Start with the intial guesses of x0 = { -1.5, -0.5, 1}

x0 = linspace(330,400,30);

% Solve the problem to tolrance of tol = 1e-4

tol = 1e-4;

for i = 1: maxit 
    y = root_finder(f, x0(i), maxit, tol);
end

