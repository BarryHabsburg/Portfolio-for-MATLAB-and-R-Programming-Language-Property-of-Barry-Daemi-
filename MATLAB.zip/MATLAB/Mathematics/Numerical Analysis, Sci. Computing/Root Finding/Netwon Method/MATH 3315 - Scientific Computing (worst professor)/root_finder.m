function x = root_finder(f, x, maxit, tol)   
% Usage: x = root_finder(f, x, maxit, tol)
%
% This routine solves the scalar-valued nonlinear equation f(x)=0 
% using Newton's method to a tolerance of tol.
%
% inputs:   f        nonlinear root-finding function
%           x        REAL initial guess 
%           maxit    INTEGER maximum number of Newton iterations
%           tol      REAL error tolerance
% outputs:  x        REAL solution 
%
% Barry Daemi, ID 45488356
% Math3315 / CSE3365 @ SMU
% Fall 2017

% get initial function value
fx = f(x);

% check input arguments
if (floor(maxit) < 1) 
   fprintf('root_finder: maxit = %i < 1. Resetting to 10\n',floor(maxit)); 
   maxit = 10;
end
if (tol < eps)
   fprintf('root_finder: tol = %g < %g. Resetting to %g\n',tol,eps,10*eps)
   tol = 10*eps;
end
if (abs(fx) < tol)
   disp('initial guess solved the problem!') 
   return
end

% begin iteration
fprintf(' Root Finder, initial T = %0.8f, |f(T)| = %g, tol = %g\n' , x, abs(fx), tol);
for i=1:maxit
   
   % update Newton guess
   dfx = ( f(x+fx)-fx)/(fx);
   if (abs(dfx) < eps) 
      fprintf('   Warning: nearly singular, df(x) = %g\n', dfx);
   end
   
   % update state, function value
   h = fx/dfx;
   x = x - h;
   fx = f(x);
   
   % output convergence information
   fprintf('   iter %6i, T = %0.8f, \t|f(T)| = %g\n', i, x, abs(fx));
   if ((abs(fx) < tol))
      break;
   end
   if abs(h) < tol
       break;
   end

end