% Test_Problem_2_1
% 
% Purpose: Complete a schur factorization A = QSQ'. Can apply Householder
%          reflectors from left to right to introduce zeros. 
%
% Barry Daemi, ID 45488356
% Fall 2018
% Math 6315

clear

% generate random matrix with m-by-n size
A = rand(50,50);

% solves the eigenvaue and eigenvector problem with lowerhessen
[H,Q] = lowerhessen(A);

derror = norm(A - (Q*H*Q'),1)

[P,H] = hess(A);

derror = norm(A - (P*H*P'),1)

% Note (3/29/2021): I never got a chance to fix my lower Hessenburg 
% iterative algorithm. It would be nice to actually code some Eigenvalue
% decomposition and iterative methods.