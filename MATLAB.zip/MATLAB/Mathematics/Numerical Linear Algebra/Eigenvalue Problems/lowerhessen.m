function [H,Q] = lowerhessen(A)
% Usage: [H,Q] = lowerhessen(A)
%
% Purpose: Complete a schur factorization A = QSQ'. Can apply Householder
%          reflectors from left to right to introduce zeros. 
%
% Inputs:  A      Randomly generated m-by-n sized Matrix to represent
%                 a random data set
%                 
% Outputs: H      (fix me)
%          Q      (fix me)
%
% Barry Daemi
% Math 6315
% Fall 2018

[m,n] = size(A); H = A;
if (nargout > 1)
    Q = eye(m);
end
for k = n:-1:3
    idx = n-1;
    u = H(1:idx,k);
    u(idx) = mysign(u(idx))*norm(u)+u(idx);
    u = u/norm(u);
    H(1:idx,1:k) = H(1:idx,1:k) - 2*u*(u'*H(1:idx,1:k));
    H(n:-1:1,1:idx) = H(n:-1:1,1:idx) - 2*(H(n:-1:1,1:idx)*u)*u';
    if (nargout > 1)
        % forward accumulation (backward would use less flops)
        Q(1:n,1:idx) = Q(1:n,1:idx) - 2*(Q(1:n,1:idx)*u)*u';
    end
end
