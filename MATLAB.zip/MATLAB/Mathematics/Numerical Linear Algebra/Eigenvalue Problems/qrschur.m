function [H,V] = qrschur(A,tol)
% compute A=VHV', where H converges to upper triangular

[m,n] = size(A); H = zeros(n,n);
if(nargout > 2)
    [H,V] = hessen2(A);
else
    [H] = hessen(A);
end
k = n; it = 1; itmax = n^2;
while ((k > 1) && (it <= itmax))
    %compute the wilkinson shift
    mu = eig(H(k-1:k,k-1:k));
    if(abs(mu(1)-H(k,k)) <= abs(mu(2)-H(k,k)))
        mu = mu(1);
    else
        mu = mu(2);
    end
    
    % compute QR (should use Givens or length 2-Householder instead,
    % should use implicit shift instead of explicit shift)
    [Q,R] = qr(H(1:k,1:k) - mu*eye(k));
    H(:,1:k) = H(:,1:k)*Q; H(1:k,:) = Q'*H(1:k,:);
    
    % updates V
    if(nargout > 2)
        V(:,1:k) = V(:,1:k)*Q;
    end
    
    % deflate if a subdiagonal is small enough
    if(abs(H(k,k-1)) < tol*(abs(H(k-1,k-1))+abs(H(k,k))))
        H(k,k-1) = 0; k = k-1;
    end
    it = it + 1;
end