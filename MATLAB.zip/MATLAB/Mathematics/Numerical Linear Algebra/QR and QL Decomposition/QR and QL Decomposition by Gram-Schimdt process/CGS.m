function [Q,R] = CGS(A)
% Usage: [Q,R] = CGS(A)
%
% This routine numerically approximates the integral
%    int_a^b f(x) dx
% using the composite Gaussian quadrature rule using 4 points per
% interval (i.e. O(h^8) accurate) over n subintervals. We require
% that f have the calling syntax 
%    y = f(x)
% where y has the same size and shape as x, in the case 
% that x is array-valued.
%
% Inputs:  A      Randomly generated a m-by-n sized Matrix 
%                 
% Outputs: Q      The orthogonal matrix: Q
%          R      The upper triangular matrix: R
%

n = length(A);
R(1,1) = norm(A(:,1));
Q(:,1) = A(:,1)/R(1,1);

for j = 2:n
    R(1:j-1,j) = Q(:,1:j-1)'*A(:,j);
    Q(:,j) = A(:,j) - Q(:,1:j-1)*R(1:j-1,j);
    R(j,j) = norm(Q(:,j));
    if (R(j,j) == 0) 
        error('columns linearly dependent');
    end
    Q(:,j) = Q(:,j)/R(j,j);
end
