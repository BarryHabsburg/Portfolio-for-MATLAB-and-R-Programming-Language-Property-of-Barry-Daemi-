function [Q,L] = QL_by_CGS(A)
% Usage: [Q,L] = QL_by_CGS(A)
%
% This routine numerically approximates a QL decomposition, using 
% BLAS - 2 (Basic Linear Algebra Subroutine - 2), Classical Gram-Schmidt 
% alogrithm: then to calculate the factorization and orthogonality error.
%
% Inputs:  A      Randomly generated a m-by-n sized Matrix 
%                 
% Outputs: Q      The orthogonal matrix: Q
%          L      The lower triangular matrix: L
%

[m,n]=size(A);
L(n,n)=norm(A(:,n)); Q(:,n)=A(:,n)/L(n,n); 
for j=n-1:-1:1
    L(n:-1:j+1,j)=Q(:,n:-1:j+1)'*A(:,j);
    Q(:,j)=A(:,j)-Q(:,n:-1:j+1)*L(n:-1:j+1,j);
    L(j,j)=norm(Q(:,j));
    if(L(j,j)==0), error(['Columns are linearly dependent']); end
    Q(:,j)=Q(:,j)/L(j,j);
end
