function [Q,L] = QL_by_MGS(A)
% Usage: [Q,L] = QL_by_MGS(A)
%
% This routine numerically approximates a QL decomposition, using 
% BLAS - 2 (Basic Linear Algebra Subroutine - 2), Modified Gram-Schmidt 
% alogrithm: then to calculate the factorization and orthogonality error.
%
% Inputs:  A      Randomly generated a m-by-n sized Matrix 
%                 
% Outputs: Q      The orthogonal matrix: Q
%          L      The lower triangular matrix: L
%

[m,n]=size(A); Q=A; L=zeros(m,n);
for j=n:-1:1 
    L(j,j)=norm(Q(:,j));
    if (L(j,j)==0), error('linearly dependent columns'); end
    Q(:,j)=Q(:,j)/L(j,j);
    L(j,j-1:-1:1)=Q(:,j)'*Q(:,j-1:-1:1);
    Q(:,j-1:-1:1)=Q(:,j-1:-1:1)-Q(:,j)*L(j,j-1:-1:1);
end

