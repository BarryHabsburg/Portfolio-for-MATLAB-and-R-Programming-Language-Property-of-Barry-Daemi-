function [Q,R,Error] = QR_by_GS(A, method)
% Usage: [Q,R,Error] = QR_by_GS(A, method)
%
% This routine numerically approximates a thin QR decomposition, using 
% BLAS - 2 (Basic Linear Algebra Subroutine - 2), Classical Gran-Schmidt, 
% or Modified Gram-Schmidt alogrithm: then to calculate the respective
% factorization and orthogonality error of the respective methods.
% 
% algorithm. This method was created by
%
% Inputs:  A          Randomly generated A matrix of m x n size
%          Methods    Variable determines the type of GS used
%                     
% Outputs: Q          (fix me)
%          R          (fix me)
%          Error      Matrix that stores, two errors: Fractorization 
%                     and Orthogonality Error
%

n = length(A);
Error = zeros(2,1);
I = eye(n,n);

if (method == 'CGS')
    [Q,R] = CGS(A);
end

if (method == 'MGS')
    [Q,R] = MGS(A);
end

% calculation of the Factorization and Orthogonality error
Error(1,1) = norm(A - (Q*R));
Error(2,1) = norm(I - (Q'*Q));

