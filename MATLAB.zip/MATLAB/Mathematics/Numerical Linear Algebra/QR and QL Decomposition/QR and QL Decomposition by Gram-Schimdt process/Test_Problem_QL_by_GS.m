% Test_Problem_13
% 
% Purpose: 
%
% Barry Daemi, ID 45488356
% Fall 2018
% Math 6315

clear

% generate random matrix with m-by-n size
 A = rand(10,10);

% Calculate QR decomposition by Classical Gran-Schmidt
[Q,R,Error] = QR_by_GS(A, 'CGS')

% Calculate QR decomposition by Classical Gran-Schmidt
[Q,R,Error] = QR_by_GS(A, 'MGS')
 
% Calculate QL decomposition by Classical Gran-Schmidt
[Q0,L0,Error0] = QL_by_GS(A, 'CGS')

% Calculate QL decomposition by Classical Gran-Schmidt
[Q1,L1,Error1] = QL_by_GS(A, 'MGS')





