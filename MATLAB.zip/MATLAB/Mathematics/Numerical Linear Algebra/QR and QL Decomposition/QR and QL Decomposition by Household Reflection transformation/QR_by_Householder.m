function [Q,R,Error] = QR_by_Householder(A)
% Usage: [Q,R,Error] = QR_by_Householder(A)
%
% This routine numerically approximates a thin QR decomposition, using 
% BLAS - 3 (Basic Linear Algebra Subroutine - 3) Householder reflection 
% algorithm. This algrothm was created by Bindel, from Cornell, and modified
% by Barry Daemi. Citation included in text file, in zip file: named,
% Problem 1.2.
%
% Inputs:  A      Randomly generated a m-by-n sized Matrix
%                 
% Outputs: Q      The orthogonal matrix: Q
%          R      The upper triangular matrix: R
%          Error  Matrix that stores, two errors: Factorization 
%                 and Orthogonality Error
%

[m,n] = size(A);
Q = eye(m);
R=A;

for j = 1:n
    normx = norm(R(j:n,j));
    s = -mysign(R(j,j));
    u1 = R(j,j) - s*normx;
    w = R(j:n,j)/u1;
    w(1) = 1;
    tau = -s*u1/normx;
    
    R(j:n,:) = R(j:n,:) - (tau*w)*(w'*R(j:n,:));
    Q(:,j:n) = Q(:,j:n) - (Q(:,j:n)*w)*(tau*w)';
end

R=triu(R(1:n,1:m));

% Calculates the factorization and orthogonality error
Error = zeros(2,1);
I = eye(m);
Error(1,1) = norm(A - (Q*R));
Error(2,1) = norm(I - (Q'*Q));
