function [Q,L,Error] = QL_by_Householder(A)
% Usage: [Q,R,Error] = QL_by_Householder(A)
%
% This routine numerically approximates a thin QR decomposition, using 
% BLAS - 3 (Basic Linear Algebra Subroutine - 3)Householder reflection 
% algorithm. This algrothm was created by Bindel, from Cornell, and modified
% by Barry Daemi. Citation included in text file, in zip file: named,
% Problem 1.2.
%
% Inputs:  A      Randomly generated a m-by-n sized Matrix
%                 
% Outputs: Q      The orthogonal matrix: Q
%          L      The upper triangular matrix: R
%          Error  Matrix that stores, two errors: Factorization 
%                 and Orthogonality Error
%

[m,n] = size(A);
Q = eye(m);
L=A;

for j = n:-1:1
    normx = norm(L(j:-1:1,j));
    s = -sign(L(j,j));
    u1 = L(j,j) - s*normx;
    w = L(j:-1:1,j)/u1;
    w(1) = 1;
    tau = -s*u1/normx;
    
    L(j:-1:1,:) = L(j:-1:1,:) - (tau*w)*(w'*L(j:-1:1,:));
    Q(:,j:-1:1) = Q(:,j:-1:1) - (Q(:,j:-1:1)*w)*(tau*w)';
end

% Calculate the factorization and orthogonality error
Error = zeros(2,1);
I = eye(n,n);
Error(1,1) = norm(A - (Q*L));
Error(2,1) = norm(I - (Q'*Q));
