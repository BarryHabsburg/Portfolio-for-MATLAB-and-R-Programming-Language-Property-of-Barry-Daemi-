function [outsign]=mysign(s)
%
% directly using the built-in sign() is incorrect,
% because the built-in sign() has sign(0)=0, 
% which makes the Householder reflector wrong. 
% use  mysign() instead for the reflector construction. 
%
% another concern is that for complex s, one has to
% keep the complex sign as done in sign().
%
    if (abs(s)==0), 
        outsign=1; 
    else 
        outsign=s/abs(s); 
    end