% Test_Problem_17
% 
% Purpose: (fix me)
%
% Barry Daemi, ID 45488356
% Fall 2018
% Math 6315

clear

% generate random matrix with m-by-n size
%A = [11 14 23; 12 21 24; 13 22 31];
A = rand(10,10);

% solves the QL decomposition using Householder reflectors

[Q,R,Error1] = QR_by_Householder(A)
[Q,L,Error2] = QL_by_Householder(A)


