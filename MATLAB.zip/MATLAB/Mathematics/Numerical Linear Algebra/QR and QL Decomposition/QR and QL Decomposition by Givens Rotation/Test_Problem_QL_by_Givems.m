% Problem_1_6
% 
% Purpose: Thin QL decomposition using Givens Rotations algorithm. 
%          And second objective, is to measure, the Factorization and 
%          Orthogonality error produced by this subroutine.
%
% Barry Daemi, ID 45488356
% Fall 2018
% Math 6315

clear

% generate random matrix with m-by-n size
 A = [0.5634 0.0634 0.8700; 
      0.0305 0.9801 0.5706;
      0.0422 0.6810 0.5959];

% Calculates QR decomposition by Given Rotation matrices
[Q,R,Error] = QR_by_Givens(A)
  
% Calculates QL decomposition by Givens Rotation matrices
[Q,L,Error] = QL_by_Givens(A)



