function [Q,L,Error] = QL_by_Givens(A)
% Usage: [Q,L,Error] = QL_by_Givens(A)
%
% This routine numerically approximates a thin QR decomposition, using 
% Givens Rotation algorithm. And measures the subroutine factorization 
% and Orthogonality error.
%
% Inputs:  A      Randomly generated a m-by-n sized Matrix
%                 
% Outputs: Q      The orthogonal matrix: Q
%          L      The lower triangular matrix: L
%          Error  Matrix that stores, two errors: Factorization 
%                 and Orthogonality Error
%

[m,n] = size(A);
Q = eye(m);
L=A;

for j = 1:n
    for i = m:-1:(j+1)
        G = eye(m);
        [c,s] = givensrotation(L(i-1,j),L(i,j));
        G([i-1,i],[i-1,i]) = [c -s; s c];
        L = G'*L;
        Q = Q*G;
    end
end

Q = Q';
L = L';

% Error matrix: Factorization and Orthogonality error
Error = zeros(2,1);
I = eye(size(A));

% calculation of the Factorization and Orthogonality error
Error(1,1) = norm(A - (L*Q)');
Error(2,1) = norm(I - (Q*Q'));


    
