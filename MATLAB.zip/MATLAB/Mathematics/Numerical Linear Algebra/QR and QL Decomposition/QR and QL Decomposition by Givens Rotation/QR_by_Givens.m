function [Q,R,Error] = QR_by_Givens(A)
% Usage: [Q,R,Error] = QR_by_Givens(A)
%
% This routine numerically approximates a thin QR decomposition, using 
% Givens Rotation algorithm. And measures the subroutine factorization 
% and Orthogonality error.
%
% Inputs:  A      Randomly generated a m-by-n sized Matrix
%                 
% Outputs: Q      The orthogonal matrix: Q
%          R      The upper triangular matrix: R
%          Error  Matrix that stores, two errors: Factorization 
%                 and Orthogonality Error
%

[m,n] = size(A);
Q = eye(m);
R=A;

for j = 1:n
    for i = m:-1:(j+1)
        G = eye(m);
        [c,s] = givensrotation(R(i-1,j),R(i,j));
        G([i-1,i],[i-1,i]) = [c -s; s c];
        R = G'*R;
        Q = Q*G;
    end
end

% Error matrix: Factorization and Orthogonality error
Error = zeros(2,1);
I = eye(size(A));

% calculation of the Factorization and Orthogonality error
Error(1,1) = norm(A - (Q*R));
Error(2,1) = norm(I - (Q'*Q));


    
