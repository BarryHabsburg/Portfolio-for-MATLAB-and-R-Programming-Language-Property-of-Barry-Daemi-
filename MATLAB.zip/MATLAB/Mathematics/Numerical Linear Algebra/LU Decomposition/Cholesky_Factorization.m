function [R,Error] = Cholesky_Factorization(A)
% Usage: [R,Error] = Cholesky_Factorization(A)
%
% This routine numerically approximates a Cholesky decomposition, using 
% BLAS (Basic Linear Algebra Subroutine)algorithm: then is designed 
% calculate the respective factorization error that occurs from
% calculation.
% 
%
% Inputs:  A          Randomly generated A matrix of m x n size
%                     
% Outputs: R          Hermitian upper triangular form
%          Error      Fractorization Error
%

[m,n] = size(A);
R = A;
for k = 1:n
    for j = k+1:n
        R(j,j:n) = R(j,j:n) - R(k,j:n)*R(k,j)'/R(k,k);
    end
    if (R(k,k) <= 0)
        error('A is not HPD, try ''A=R^*DR''instead')
    end
    R(k,k:n) = R(k,k:n)/sqrt(R(k,k));
end
R = triu(R);

Error = norm((A - (R'*R)),1);