% Problem_2_3
% 
% Purpose: This routine numerically approximates a LU decomposition with 
%          non-pivoting and partial-poviting algorithm. These algorithms 
%          were modified: so that, we could use a right matrix multiplication 
%          with an inverse U (unit upper tringular) matrix to transform A into a
%          L (lower triangular) matrix.
%          Second objective, was to measure the errors, of both algorithm L's
%          produced by A*inv(U) with the expected L (produced) by the normal
%          UL decomposition algorithm.
%
% Barry Daemi, ID 45488356
% Fall 2018
% Math 6315

clear

% generate random matrix with m-by-n size
A = rand(10,10);

% solves the LU decomposition using GE algorithm
[U,L,Error] = LU_decomposition_by_GE(A)

% solves the LU decomposition using GEpiv algorithm
[U,L,P,Error] = LU_decomposition_by_GEpiv(A)

% solves the LU decomposition using nonpivoting GE algorithm (only forms L)
[L] = LU_decomposition_nonpivoting(A)

% solves the for Cholesky Decomposition
A=A'*A; % Forces A to become Hermitian Positive-Definite (HPE)
[R,Error] = Cholesky_Factorization(A)







