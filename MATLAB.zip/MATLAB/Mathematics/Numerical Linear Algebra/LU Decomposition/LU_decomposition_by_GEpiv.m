function [U,L,P,Error] = LU_decomposition_by_GEpiv(A)
% Usage: [L,U,P,Error] = UL_decomposition_by_GEpiv(A)
%
% This routine numerically approximates a LU decomposition with partial-pivoting
% algorithm, using a right matrix multiplication with an 
% inverse U (unit upper tringular) matrix to transform A into a
% L (lower triangular) matrix.
%
%
% Inputs:  A      Randomly generated m-by-n sized Matrix to represent
%                 a random data set
%                 
% Outputs: L      Lower triangular matrix
%          U      Upper triangular matrix
%          P      Permutation vector
%          Error  the error from the algorithm's calculations
%

[m,n] = size(A);
P = 1:n;

for k = n:-1:1
    [maxv,r] = max(abs(A(k:n)));
    q = r+k-1;
    P([k q]) = P([q k]);
    A([k q],:) = A([q k],:);
    if (A(k,k) ~= 0)
        A(k-1:-1:1,k) = A(k-1:-1:1,k)/A(k,k);
        A(k-1:-1:1,k-1:-1:1) = A(k-1:-1:1,k-1:-1:1) - A(k-1:-1:1,k)*A(k,k-1:-1:1);
    end
end

U = eye(n,n) + triu(A,0);
U_inverse = inv(U);
L = tril(A);
Error = norm((A) - ((A*U_inverse)*(U)));

