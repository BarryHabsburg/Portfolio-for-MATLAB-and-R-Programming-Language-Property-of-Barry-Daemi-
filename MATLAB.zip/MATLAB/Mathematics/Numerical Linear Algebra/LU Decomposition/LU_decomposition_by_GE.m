function [U,L,Error] = LU_decomposition_by_GE(A)
% Usage: [U,L,Error] = LU_decomposition_by_GE(A)
%
% This routine numerically approximates a LU decomposition with non-pivoting
% algorithm, using a right matrix multiplication with an 
% inverse U (unit upper tringular) matrix to transform A into a
% L (lower triangular) matrix.
%
% Inputs:  A      Randomly generated m-by-n sized Matrix to represent
%                 a random data set
%                 
% Outputs: L      Lower triangular matrix
%          U      Inversed upper trianguler matrix
%          Error  the error from the algorithm's calculations
%

[m,n] = size(A);

for k = n:-1:1
    if (A(k,k) == 0)
        error('without pivoting, LU decomposition will fail')
    else
        A(k-1:-1:1,k) = A(k-1:-1:1,k)/A(k,k);
        A(k-1:-1:1,k-1:-1:1) = A(k-1:-1:1,k) - A(k-1:-1:1,k)*A(k,k-1:-1:1);
    end
end
U = eye(n,n) + triu(A,0);
U_inverse = inv(U);
L = tril(A);
Error = norm((A) - ((A*U_inverse)*(U)));
