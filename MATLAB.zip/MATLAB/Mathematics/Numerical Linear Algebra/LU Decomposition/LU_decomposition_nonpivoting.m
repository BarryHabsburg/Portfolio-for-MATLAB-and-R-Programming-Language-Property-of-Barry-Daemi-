function [A] = LU_decomposition_nonpivoting(A)
% Usage: [A] = LU_decomposition_nonpivoting(A)
%
% This routine numerically approximates a LU decomposition, using 
% a LU decomposition with non-pivoting algorithm. 
%
% Inputs:  A      Randomly generated m-by-n sized Matrix to represent
%                 a random data set
%                 
% Outputs: A      Matrix stores both: Matrix L (lower triangular matrix)
%                 and U (Upper trianguler matrix)
%

[~,m]=size(A);
for k = 1:m-1
    if (A(k,k) == 0)
        error('without pivoting, LU decomposition fails')
    else
        A(k+1:m,k) = A(k+1:m,k)/A(k,k);
        A(k+1:m,k+1:m) = A(k+1:m,k+1:m) - A(k+1:m,k)*A(k,k+1:m);
    end
end
