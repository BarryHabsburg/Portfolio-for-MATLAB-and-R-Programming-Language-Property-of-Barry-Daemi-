% Project #2
% 
%

clear
close all

% Problem 8.2: Write a MATLAB function [Q,R] mgs(A) (see next lecture) that 
% computes a reduced QR factorization A=QR of an m x n matrix A with m >= n
% using modifed Gram-Schmidt orthogonalization. The output variables are a
% martix Q (within complex domain m x n) with orthonormal columns and a 
% triangular matrix R (within complex domain n x n)
n=10; m=15;
A=randn(n,m);

[Q,R] = MGS(A);

% Problem 10.2: (a) Write a MATLAB function [W,R] house(A) that computes an
% implicit representation of a full QR factorization A=QR of an m x n
% matrix A with m >= n using Householder reflections. The output variables
% are a lower-triangular matrix W (within complex domain m x n) whose
% columns are the vectors V(k) defining the succesiove Householder
% reflections, and a triangular matrix R (within complex domain n x n).

n=10;
A=randn(n,n);

[W,R] = house(A);

% Problem 10.2: (b)Write a MATLAB function Q=formQ(W) that takes the matrix
% W produced by house.m as input and generates a corresponding m x m
% orthogonal matrix Q.

Q = formQ(W);

Error = zeros(2,1);
[n,m]=size(A);
I = eye(n,n);
Error(1,1) = norm(A - (Q*R));
Error(2,1) = norm(I - (Q'*Q));

% Problem 10.2: Compute three reduced QR factorization of Z in MATLAB: by
% the Gram-Schmidt rountine mgs.m of Exercise 8.2, by Householder routines
% house.m and formQ.m of Excercise 10.2, and by MATLAB's built-in command
% [Q,R]=qr(Z,0). Compare these three and comment on any differences you
% see.

Z=[1 2 3;4 5 6;7 8 7;4 2 3;4 2 2];

[Q,R] = MGS(Z);

[W,R] = house(Z);
Q = formQ(W);


[Q,R]=qr(Z,0);

% Problem 11.3: Take m=50, n=12. Using MATLAB's linspace, define t to be
% the m-vector corresponding to linearly spaced grid points from 0 to 1.
% using MATLAB's vander.m and fliplr, define A to be the m x n matrix
% associated with least sqaures fitting on this grid by a polynomial of
% degree n-1. Take b to be the function cos(4t) evaluated on the grid. Now,
% calculate and print (to sixteen-digit precision) the least sqaures
% coefficient vector x by six methods:

m=50; n=12;
t=linspace(0,1,m);

A=fliplr(vander(t));
A=A(:,1:n);
b=cos(4*t)';

% Problem 11.3: (a) Formation and solution of the normal equations, using
% MATLAB'S \
[R,~] = Cholesky_Factorization(A'*A);
x1=R\(R'\(A'*b));
Error1 = norm((A*x1) - b);

% Problem 11.3: (b) QR factorization computed by mgs.m (modified Gram-Schmid
% Exercise 8.2)

[Q,R] = MGS(A);
x2=R\(Q'*b);
Error2 = norm((A*x2) - b);

% Problem 11.3: (c) QR factorization computed by house.m (Householder
% triangularization,Exercise 10.2

[W1,R] = house(A);
Q = formQ(W1);
x3=R\(Q'*b);
Error3 = norm((A*x3) - b);

% Problem 11.3: (d) QR factorization computed by MATLAB's qr.m (also
% Householder triangularization)
[Q,R]=qr(A,0);
x4=R\(Q'*b);
Error4 = norm((A*x4) - b);

% Problem 11.3: (e) x=A\b in MATLAB (also based on QR factorization)
x5=A\b;
Error5 = norm((A*x5) - b);

% Problem 11.3: (f) SVD, MATLAB's svd.m
[U,S,V]=svd(A);
x6=V*(S\(U'*b));
Error6 = norm((A*x6) - b);

x=[x1,x2,x3,x4,x5,x6];
Error=[Error1,Error2,Error3,Error4,Error5,Error6];
vars={'x1','x2','x3','x4','x5','x6'};
xt=x(1:n,1:6);
fig = uifigure('Name', 'Table of Least Sqaure coefficient X vectors');
%fig=uifigure('Position',[500 500 750 350]);
uit=uitable(fig,'Position',[500 500 750 350]);
uit.Position=[20 20 710 310];
uit.Data=xt;
uit.ColumnName={'x1','x2','x3','x4','x5','x6'};
uit.RowName ={'a1','a2','a3','a4','a5','a6','a7','a8','a9','a10','a11','a12'};


% To show the overal Factorization and Orthogonality error of 
n=10:10:1000;
Factorization_Error=zeros(length(n),3); Orthogonality_Error=zeros(length(n),3);
FactError=zeros(length(n),1); OrthoError=zeros(length(n),1);

for i=1:length(n)
    A=randn(n(i),n(i));
    I = eye(n(i),n(i));
    [Q,R] = MGS(A);
    FactError(i)=norm(A - (Q*R));
    OrthoError(i)=norm(I - (Q'*Q));
end
Factorization_Error(:,1)=FactError(:);
Orthogonality_Error(:,1)=OrthoError(:);

for i=1:length(n)
    A=randn(n(i),n(i));
    I = eye(n(i),n(i));
    [W,R] = house(A);
    Q = formQ(W);
    FactError(i)=norm(A - (Q*R));
    OrthoError(i)=norm(I - (Q'*Q));
end
Factorization_Error(:,2)=FactError(:);
Orthogonality_Error(:,2)=OrthoError(:);

for i=1:length(n)
    A=randn(n(i),n(i));
    I = eye(n(i),n(i));
    [Q,R]=qr(A,0);
    FactError(i)=norm(A - (Q*R));
    OrthoError(i)=norm(I - (Q'*Q));
end
Factorization_Error(:,3)=FactError(:);
Orthogonality_Error(:,3)=OrthoError(:);

figure (1)
hold on
plot(n,Factorization_Error(:,1))
plot(n,Factorization_Error(:,2))
plot(n,Factorization_Error(:,3))
title('Factorization Error for QR Factorization Algorithms')
xlabel('size of Matrix A')
ylabel('Factorization Error')
legend({'MGS','House', 'qr'})
hold off


figure (2)
hold on
plot(n,Orthogonality_Error(:,1))
plot(n,Orthogonality_Error(:,2))
plot(n,Orthogonality_Error(:,3))
title('Orthogonality Error for QR factorization Algorithms')
xlabel('size of Matrix A')
ylabel('Orthogonality Error')
legend({'MGS','House', 'qr'})
hold off

