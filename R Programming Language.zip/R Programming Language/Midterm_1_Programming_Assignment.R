# Midterm 1 Programming assignment
rm(list = ls())

library("ggplot2") # Only Library package import

# Imports the data as a Data Frame
Operating_Budget <- data.frame(read.csv("~/Operating_Budget.csv"), stringsAsFactors = FALSE)

# Note: The goal of this program is to perform an analysis on the DallaS'S Operating budget
# to compare Fiscal budget size between 2019 and 2020. And furthermore, compare the size of 
# allocated funds for salaries, medical benefits, and retirement expenditures for both respective
# Fiscal years.

# Creates two vectors: OBJECTGROUP_PS and OBJECTGROUP_ALL
OBJECTGROUP_PS<-as.character(Operating_Budget$OBJECTGROUP[Operating_Budget$OBJECTGROUP == "Personnel Services"]) 
OBJECTGROUP_ALL<-as.character(Operating_Budget$OBJECTGROUP[Operating_Budget$OBJECTGROUP]) 

# Reduces the data.frame to only data related to Personal Services
Operating_Budget2<-Operating_Budget[OBJECTGROUP_ALL %in% OBJECTGROUP_PS,]

# Reduces the data.frame to Fiscal Year 2019, and creates an object: Operating_Budget2019
Operating_Budget2019<-Operating_Budget2[Operating_Budget2$BFY==2019,]

# Reduces the data.frame to Fiscal Year 2020, and creates an onject: Operating_Budget2020
Operating_Budget2020<-Operating_Budget2[Operating_Budget2$BFY==2020,]

# Operating Budget of Dallas for Fiscal Year 2019
Budget_Fiscal_Year_2019<-Operating_Budget2019$BUDCURR
Budget_Fiscal_Year_2019<-sum(Budget_Fiscal_Year_2019)

# Operating Budget of Dallas for Fiscal Year 2020
Budget_Fiscal_Year_2020<-Operating_Budget2020$BUDCURR
Budget_Fiscal_Year_2020<-sum(Budget_Fiscal_Year_2020)

# The ratio of Fiscal Year 2019 and 2020 of Dallas Operating Budget for these respective Fiscal Years (pertaining to Personal Services Expenditures of each Fiscal Year)
Ratio_diff<-Budget_Fiscal_Year_2020/Budget_Fiscal_Year_2019

# Displays the Ratio difference between Fiscal Year 2019 and 2019
Ratio_diff

# From this analysis, we were able to determine that the Operating Budget for Personal Services expenditures increased from Fiscal Year 2019 to 2020.
# The Personal Services Expenditure increased by 1.006674% from Fiscal Year 2019 to 2020. 
