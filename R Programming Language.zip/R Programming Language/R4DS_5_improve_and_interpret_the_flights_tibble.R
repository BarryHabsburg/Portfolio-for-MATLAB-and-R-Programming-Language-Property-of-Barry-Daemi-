# R4DS 5 - improve and interpret the flights tibble
rm(list = ls())

library(nycflights13)
library(tidyverse)
library(ggplot2)

# Stores the flights tibble into an object named flights_tibble
flights_tibble<-flights

# Extracts the dep_time column from flights_tibble, and creates a smaller tibble
# with three columns, dep time, hour, and minutes
dep_times<-transmute(flights_tibble,
          dep_time,
          hour = dep_time %/% 100,
          minute = dep_time %% 100)

# Converts dep_time from military time to minutes from midnight, then
# creates a new column in flights_tibble named dep_time_min
flights_tibble$dep_time_min <-dep_times$hour*60+dep_times$minute


sched_dep_time<-transmute(flights_tibble, sched_dep_time,hour = sched_dep_time %/% 100,minute = sched_dep_time %% 100)

# Converts dep_time from military time to minutes from midnight, then
# creates a new column in flights_tibble named sch_dep_min
flights_tibble$sched_dep_min<-(sched_dep_time$hour*60)+sched_dep_time$minute

# calculates the delays in minutes
flights_tibble$dep_delay_min<-flights_tibble$dep_time_min-flights_tibble$sched_dep_min

# ggplot for the top 10 most delayed flights by tailnum
flights_tibble%>% drop_na() %>% filter(dep_delay_min>600) %>% ggplot()+geom_bar(aes(x=reorder(tailnum, -dep_delay_min),y=dep_delay_min),stat="identity")+coord_flip()

# ggplot for the top 35 most ealier flights by tailnum
flights_tibble%>% drop_na() %>% filter(dep_delay_min<(-1435)) %>% ggplot()+geom_bar(aes(x=reorder(tailnum, -dep_delay_min),y=dep_delay_min),stat="identity")+coord_flip()
