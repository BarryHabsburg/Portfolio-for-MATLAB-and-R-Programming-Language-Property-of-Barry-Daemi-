# HOPR 6 & 7: Do some fun stuff with real data
rm(list = ls())

library("ggplot2") # Only Library package import

# Imports the data as a Data Frame
Restaurant_and_Food_Establishment_Inspections_ <- data.frame(read.csv("~/Restaurant_and_Food_Establishment_Inspections_.csv", header=FALSE), stringsAsFactors = FALSE)
# View data.frame and tests for factors in the data
View(Restaurant_and_Food_Establishment_Inspections_)
is.factor(Restaurant_and_Food_Establishment_Inspections_)

# Pulls out ZIP Codes that are not equal to 75205, et ceteria (SMU's ZIP code)
Restaurant_and_Food_Establishment_Inspections_$V11[Restaurant_and_Food_Establishment_Inspections_$V11 ==c(75205, 75204, 75219, 75209, 75225,75206, 75214)]
ZIP_codes<-as.numeric(as.character(Restaurant_and_Food_Establishment_Inspections_$V11[Restaurant_and_Food_Establishment_Inspections_$V11 ==c(75205, 75204, 75219, 75209, 75225,75206, 75214)]))

# Pulls all ZIP codes from the data.frame
All_ZIP_codes<-as.numeric(as.character(Restaurant_and_Food_Establishment_Inspections_$V11[Restaurant_and_Food_Establishment_Inspections_$V11]))

# Method to remove the NA from atomic vector ZIP_codes
remove=c(NA)
ZIP_codes<-ZIP_codes[! ZIP_codes %in% remove]

# Removes the ZIP codes that are not related to the following Zip Codes 75205, et ceteria
Restaurant_and_Food_Establishment_Inspections_2<-Restaurant_and_Food_Establishment_Inspections_[All_ZIP_codes %in% ZIP_codes,]

# Pulls the Inspection Dates from the data.frame, which are stored as Strings
Restaurant_and_Food_Establishment_Inspections_2$V3
Inspect_date<-as.character(Restaurant_and_Food_Establishment_Inspections_2$V3)
Inspect_date<-as.character(Inspect_date)

# Converts the String dates in actual numeric Dates 
Inspect_date_Num<-as.Date(Inspect_date, "%m/%d/%y", tryFormats = c("%m-%d-%y", "%m/%d/%y"))
Inspect_date_Num

# Removes the c("POSIXct", "POSIXt") from Inspect_date
class(Inspect_date_Num) <- NULL
# Displays the new non-POSIXCT and non-POSIXT dates
Inspect_date_Num

# Adds the new object Inspect_date_Num to Restaurant_and_Food_Establishment_Inspections_2
Restaurant_and_Food_Establishment_Inspections_2$V115<-Inspect_date_Num
View(Restaurant_and_Food_Establishment_Inspections_2)

# Pulls Inspection scores for the Restaurants in the specific ZIP codes 75205, et ceteria; but does not store into an object
Restaurant_and_Food_Establishment_Inspections_2$V4

# Pulls Inspection scores for the Restaurants in the specified ZIP codes 75205, et ceteria; assigns into Inspect_Score object
Inspect_scores<-as.numeric(as.character(Restaurant_and_Food_Establishment_Inspections_2$V4))

# Plot the Inspection Scores against Inspection Dates as a scatterplot
qplot(Inspect_date_Num,Inspect_scores)
# Plot the Inspection Scores as an histogram
qplot(Inspect_scores)

# Writes a CVS file in the destined directory on this PC
write.csv(Restaurant_and_Food_Establishment_Inspections_2, file="Restaurant_and_Food_Establishment_Inspections_2")
