# TMWR 2: Tidy text format and Civil War History II

# Explanation: After evaulating the four provided lexicons; I was able to determine, that the ncr lexicon
# was most suited to sentiment analysis of these Historical documents. Extrapolating, divulged into the
# four respective lexicons, I found that only NRC contianed the frequent sentiment words that are
# found in these Historical documents. Therefore, I conclude that the other three respective lexicions were
# ill-suited for this type of sentiment analyzement. 

rm(list = ls())

library(tidyverse)
library(tidytext)

# Imports the State Declaration of Session of the Civil War as
# Tidy Tibble
text_df <- read_csv("declarations")

# Grouping the Declaration of Causes to their respective author State
tidy_declares <- text_df %>%
  group_by(state) %>%
  mutate(linenumber = row_number(), ignore_case = TRUE) %>%
  ungroup() %>%
  unnest_tokens(word, text)

# get the net sentiment per 1-line section
library(tidyr)

# Before this codes execution tidy_declares had 8,289 words from the
# five states Declaration of Causes for Sesseion. After the excution of
# the below code, which removed stop_words, the tidy_declares 
# tidy tibble contained 3,270 words. 
tidy_declares <- tidy_declares %>% anti_join(stop_words)

tidy_declares_sentiment <- tidy_declares %>%
  inner_join(get_sentiments("nrc")) %>%
  # What is %/%? Also check out %%.
  count(state, index = linenumber %/% 1, sentiment) %>%
  spread(sentiment, n, fill = 0) %>%
  mutate(sentiment = positive - negative)

# cute plots for tidy_declares_sentiment analysis with nrc lexicon
library(ggplot2)

ggplot(tidy_declares_sentiment, aes(index, sentiment, fill = state)) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~state, ncol = 2, scales = "free_x")

######################## Individual State Sentiment Analysis ###############

# Virginia
Virginia <- tidy_declares %>% 
  filter(state == "Virginia")
count(Virginia) # 128 words

Virginia %>%
  count(word, sort = TRUE) %>%
  filter(n > 2) %>%
  mutate(word = reorder(word, n)) %>% 
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip()


Virginia_sentiment <- Virginia %>% inner_join(get_sentiments("nrc")) %>%
  # What is %/%? Also check out %%.
  count(state, index = linenumber %/% 1, sentiment) %>%
  spread(sentiment, n, fill = 0) %>%
  mutate(sentiment = positive - negative)

ggplot(Virginia_sentiment, aes(index, sentiment, fill = state)) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~state, ncol = 2, scales = "free_x")

Virginia_freq<-Virginia %>%
  count(word, sort = TRUE) %>%
  filter(n > 2)
Virginia_freq[,2]<-Virginia_freq[,2]/128

Virginia_freq %>% 
  mutate(word = reorder(word, n)) %>% 
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip()

# Texas
Texas <- tidy_declares %>% 
  filter(state == "Texas")
count(Texas) # 694 words

Texas %>%
  count(word, sort = TRUE) %>%
  filter(n > 5) %>%
  mutate(word = reorder(word, n)) %>% 
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip()

Texas_sentiment <- Texas %>% inner_join(get_sentiments("bing")) %>%
  # What is %/%? Also check out %%.
  count(state, index = linenumber %/% 1, sentiment) %>%
  spread(sentiment, n, fill = 0) %>%
  mutate(sentiment = positive - negative)

ggplot(Texas_sentiment, aes(index, sentiment, fill = state)) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~state, ncol = 2, scales = "free_x")

Texas_freq<-Texas %>%
  count(word, sort = TRUE) %>%
  filter(n > 5)
Texas_freq[,2]<-Texas_freq[,2]/694

Texas_freq %>% 
  mutate(word = reorder(word, n)) %>% 
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip()

# South Carolina
South_Carolina <- tidy_declares %>% 
  filter(state == "South Carolina")
count(South_Carolina) # 841 words

South_Carolina %>%
  count(word, sort = TRUE) %>%
  filter(n > 6) %>%
  mutate(word = reorder(word, n)) %>% 
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip()

South_Carolina_sentiment <- South_Carolina %>% inner_join(get_sentiments("bing")) %>%
  # What is %/%? Also check out %%.
  count(state, index = linenumber %/% 1, sentiment) %>%
  spread(sentiment, n, fill = 0) %>%
  mutate(sentiment = positive - negative)

ggplot(South_Carolina_sentiment, aes(index, sentiment, fill = state)) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~state, ncol = 2, scales = "free_x")

SC_freq<-South_Carolina %>%
  count(word, sort = TRUE) %>%
  filter(n > 6)
SC_freq[,2]<-SC_freq[,2]/128

SC_freq %>% 
  mutate(word = reorder(word, n)) %>% 
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip()


# Mississippi
Mississippi <- tidy_declares %>% 
  filter(state == "Mississippi")
count(Mississippi) # 271 words

Mississippi %>%
  count(word, sort = TRUE) %>%
  filter(n > 2) %>%
  mutate(word = reorder(word, n)) %>% 
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip()

Mississippi_sentiment <- Mississippi %>% inner_join(get_sentiments("nrc")) %>%
  # What is %/%? Also check out %%.
  count(state, index = linenumber %/% 1, sentiment) %>%
  spread(sentiment, n, fill = 0) %>%
  mutate(sentiment = positive - negative)

ggplot(Mississippi_sentiment, aes(index, sentiment, fill = state)) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~state, ncol = 2, scales = "free_x")

Mississippi_freq<- Mississippi %>%
  count(word, sort = TRUE) %>%
  filter(n > 2)
Mississippi_freq[,2]<-Mississippi_freq[,2]/271

Mississippi_freq %>% 
  mutate(word = reorder(word, n)) %>% 
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip()

# Georgia
Georgia <- tidy_declares %>% 
  filter(state == "Georgia")
count(Georgia) # 1336 words

Georgia %>%
  count(word, sort = TRUE) %>%
  filter(n > 10) %>%
  mutate(word = reorder(word, n)) %>% 
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip()

Georgia_sentiment <- Georgia %>% inner_join(get_sentiments("nrc")) %>%
  # What is %/%? Also check out %%.
  count(state, index = linenumber %/% 1, sentiment) %>%
  spread(sentiment, n, fill = 0) %>%
  mutate(sentiment = positive - negative)

ggplot(Georgia_sentiment, aes(index, sentiment, fill = state)) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~state, ncol = 2, scales = "free_x")

Georgia_freq<-Georgia %>%
  count(word, sort = TRUE) %>%
  filter(n > 10)
Georgia_freq[,2]<-Georgia_freq[,2]/128

Georgia_freq %>% 
  mutate(word = reorder(word, n)) %>% 
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip()

########## A wrap plot of the Five most frequent words from the Declarations ####################


# Top several words for each Declaration of Session 
# Note: we set (n > 8) as too many words were graphed below this number frequency,
# which made the graph illegible, and thus unless. So we settled with only three state
# wrapp graphic as or a collective graphic.
tidy_declares %>% group_by(state) %>%
  count(word, sort = TRUE) %>%
  filter(n > 8) %>%
  mutate(word = reorder(word, n)) %>% 
  ggplot(aes(word, n)) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~state, ncol = 2, scales = "free_x") +
  xlab(NULL) +
  coord_flip()  


# Histogram ofthe top 5 words from all Declarations of Session by Five States
tidy_declares %>%
  count(word, sort = TRUE) %>%
  filter(n > 30) %>%
  mutate(word = reorder(word, n)) %>% 
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip()

Data_count<-tidy_declares %>%
  count(word, sort = TRUE) %>%
  filter(n > 30)

tidy_declares_count<-c(3270,3270,3270,3270,3270)
tidy_declares_freq<-Data_count[,2]/tidy_declares_count
Data_count[,2]<-tidy_declares_freq

Data_count %>% 
  mutate(word = reorder(word, n)) %>% 
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip()

